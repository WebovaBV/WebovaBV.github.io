<?php if (!defined('ABSPATH')) exit; ?>
<div class="elementor-control elementor-control-type-select elementor-label-inline elementor-control-separator-before">
    <div class="elementor-control-content">
        <h5>BSN</h5>
        <div class="elementor-control-field">
            <label for="<?= esc_attr($this->get_field_id('bsnEnabled')) ?>" class="elementor-control-title">Invulveld</label>
            <div class="elementor-control-input-wrapper elementor-control-unit-5">
                <select name="<?= esc_attr($this->get_field_name('bsnEnabled')) ?>" id="<?= esc_attr($this->get_field_id('bsnEnabled')) ?>">
                    <option value="off" <?= selected($bsnEnabled, false, false) ?>>Uit</option>
                    <option value="on" <?= selected($bsnEnabled, true, false) ?>>Aan</option>
                </select>
            </div>
        </div>
        <div class="elementor-control-field">
            <label for="<?= esc_attr($this->get_field_id('bsnRequired')) ?>" class="elementor-control-title">Verplicht</label>
            <div class="elementor-control-input-wrapper elementor-control-unit-5">
                <select name="<?= esc_attr($this->get_field_name('bsnRequired')) ?>" id="<?= esc_attr($this->get_field_id('bsnRequired')) ?>">
                    <option value="off" <?= selected($bsnRequired, false, false) ?>>Nee</option>
                    <option value="on" <?= selected($bsnRequired, true, false) ?>>Ja</option>
                </select>
            </div>
        </div>
    </div>
</div>
