<?php
if (!defined('ABSPATH')) exit;

$appointmentTypes = vertimartGetAppointmentTypes();
$uid = wp_unique_id('vertimart-booking-');
$fields = vertimartPatientFields($bsnEnabled, $bsnRequired);
$idPrefix = $uid;

if (!$appointmentTypes):
?>
    <div style="border: 2px solid #f44336; background: #fff6f6; color: #a12727; padding: 12px; border-radius: 6px;">
        Afspraken maken is momenteel niet beschikbaar. Probeer het later opnieuw.
    </div>
<?php return; endif; ?>
<div id="<?= esc_attr($uid) ?>" class="vertimart-booking">
    <div class="vertimart-booking-message" style="display:none;margin-bottom:1rem;padding:12px;border-radius:6px;white-space:pre-line;"></div>

    <!-- Step 1: appointment type -->
    <div class="vertimart-booking-step" data-step="1">
        <div class="elementor-field-type-select elementor-field-group elementor-column elementor-col-100 elementor-field-required elementor-mark-required">
            <label for="<?= esc_attr($uid . '-type') ?>" class="elementor-field-label" style="padding-top:10px;padding-bottom:3px;">Type afspraak</label>
            <select id="<?= esc_attr($uid . '-type') ?>" class="vertimart-type elementor-field elementor-size-md elementor-field-textual" required="required">
                <option value="" disabled selected>Kies een type afspraak</option>
                <?php foreach ($appointmentTypes as $type): ?>
                    <option value="<?= esc_attr((string) $type['id']) ?>"><?= esc_html($type['name']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div style="margin-top:0.5rem;">
            <button type="button" class="vertimart-show-slots elementor-button elementor-size-md">Toon beschikbare tijden</button>
        </div>
    </div>

    <!-- Step 2: pick slot -->
    <div class="vertimart-booking-step" data-step="2" style="display:none;">
        <div class="vertimart-location-filter" style="display:none;margin-bottom:1rem;">
            <label class="elementor-field-label">Locatie</label>
            <select class="vertimart-location elementor-field elementor-size-md elementor-field-textual"></select>
        </div>
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:0.5rem;">
            <button type="button" class="vertimart-prev elementor-button elementor-size-sm">&larr;</button>
            <strong class="vertimart-range-label"></strong>
            <button type="button" class="vertimart-next elementor-button elementor-size-sm">&rarr;</button>
        </div>
        <div class="vertimart-slots"></div>
        <div style="margin-top:1rem;">
            <button type="button" class="vertimart-back-to-1 elementor-button elementor-size-sm">Terug</button>
        </div>
    </div>

    <!-- Step 3: patient details -->
    <div class="vertimart-booking-step" data-step="3" style="display:none;">
        <div class="vertimart-summary" style="margin-bottom:1rem;"></div>
        <form class="vertimart-patient-form">
            <?php if ($bsnEnabled && $bsnRequired): ?>
                <input type="hidden" name="bsnRequired" value="1">
            <?php endif; ?>
            <?php include VERTIMART_VIEWS_PATH . 'patient-fields.php'; ?>
            <div class="elementor-field-type-textarea elementor-field-group elementor-column elementor-col-100">
                <label for="<?= esc_attr($uid . '-remark') ?>" class="elementor-field-label" style="padding-top:10px;padding-bottom:3px;">Opmerkingen <small>(optioneel)</small></label>
                <textarea id="<?= esc_attr($uid . '-remark') ?>" name="remark" maxlength="<?= esc_attr((string) VERTIMART_REMARK_MAX_LENGTH) ?>" rows="3" class="elementor-field elementor-size-md elementor-field-textual"></textarea>
            </div>
            <div style="margin-top:0.5rem;display:flex;gap:0.5rem;">
                <button type="button" class="vertimart-back-to-2 elementor-button elementor-size-md">Terug</button>
                <button type="submit" class="vertimart-confirm elementor-button elementor-size-md">Bevestig afspraak</button>
            </div>
        </form>
    </div>

    <!-- Confirmation -->
    <div class="vertimart-booking-done" style="display:none;"></div>
</div>
<script>
    (function() {
        var root = document.getElementById(<?= wp_json_encode($uid) ?>);
        if (!root) return;

        var ajaxUrl = <?= wp_json_encode(admin_url('admin-ajax.php')) ?>;
        var nonce = <?= wp_json_encode(wp_create_nonce('vertimart_booking')) ?>;
        var state = {
            typeId: '',
            typeName: '',
            allSlots: [],
            range: null,
            slot: null
        };

        function q(sel) {
            return root.querySelector(sel);
        }

        function el(tag, text, className) {
            var node = document.createElement(tag);
            if (text) node.textContent = text;
            if (className) node.className = className;
            return node;
        }

        function post(action, data) {
            var body = new FormData();
            body.append('action', action);
            body.append('nonce', nonce);
            Object.keys(data).forEach(function(key) {
                body.append(key, data[key]);
            });
            return fetch(ajaxUrl, {
                method: 'POST',
                credentials: 'same-origin',
                body: body
            }).then(function(r) {
                return r.json();
            });
        }

        function showStep(n) {
            root.querySelectorAll('.vertimart-booking-step').forEach(function(step) {
                step.style.display = (step.getAttribute('data-step') == n) ? '' : 'none';
            });
        }

        function message(text, ok, errors) {
            var box = q('.vertimart-booking-message');
            if (!text) {
                box.style.display = 'none';
                return;
            }
            box.textContent = [text].concat(errors || []).join('\n');
            box.style.display = '';
            box.style.border = '2px solid ' + (ok ? '#4CAF50' : '#f44336');
            box.style.background = ok ? '#f6fff6' : '#fff6f6';
            box.style.color = ok ? '#256029' : '#a12727';
        }

        function busy(btn, on) {
            btn.disabled = on;
            btn.style.opacity = on ? '0.6' : '';
        }

        function genericError() {
            message('Er is een fout opgetreden. Probeer het later opnieuw.', false);
        }

        function formatDate(iso, options) {
            return new Date(iso + 'T00:00:00').toLocaleDateString('nl-NL', options);
        }

        // Step 1
        q('.vertimart-show-slots').addEventListener('click', function() {
            var select = q('.vertimart-type');
            if (!select.value) {
                message('Kies een type afspraak.', false);
                return;
            }
            state.typeId = select.value;
            state.typeName = select.selectedOptions[0].textContent;
            message('', true);
            showStep(2);
            loadSlots('');
        });

        // Step 2
        function loadSlots(from) {
            var slotsEl = q('.vertimart-slots');
            slotsEl.textContent = 'Laden...';
            post('vertimart_booking_slots', {
                appointmentTypeId: state.typeId,
                from: from
            }).then(function(res) {
                if (!res.success) {
                    slotsEl.textContent = '';
                    message(res.message || 'Er is een fout opgetreden.', false);
                    return;
                }
                message('', true);
                state.allSlots = res.slots || [];
                state.range = res;
                updateLocationFilter();
                renderSlots();
            }).catch(function() {
                slotsEl.textContent = '';
                genericError();
            });
        }

        function updateLocationFilter() {
            var names = [];
            state.allSlots.forEach(function(slot) {
                if (slot.locationName && names.indexOf(slot.locationName) === -1) names.push(slot.locationName);
            });
            var select = q('.vertimart-location');
            var previous = select.value;
            select.textContent = '';
            var all = el('option', 'Alle locaties');
            all.value = '';
            select.appendChild(all);
            names.forEach(function(name) {
                var option = el('option', name);
                option.value = name;
                select.appendChild(option);
            });
            select.value = names.indexOf(previous) === -1 ? '' : previous;
            q('.vertimart-location-filter').style.display = names.length > 1 ? '' : 'none';
        }

        q('.vertimart-location').addEventListener('change', renderSlots);

        function renderSlots() {
            var range = state.range;
            q('.vertimart-range-label').textContent =
                formatDate(range.from, {
                    day: 'numeric',
                    month: 'short'
                }) + ' t/m ' +
                formatDate(range.to, {
                    day: 'numeric',
                    month: 'short'
                });
            q('.vertimart-prev').style.visibility = range.prev ? '' : 'hidden';

            var location = q('.vertimart-location').value;
            var slotsEl = q('.vertimart-slots');
            slotsEl.textContent = '';

            var byDate = {};
            var dates = [];
            state.allSlots.forEach(function(slot) {
                if (location && slot.locationName !== location) return;
                if (!byDate[slot.date]) {
                    byDate[slot.date] = [];
                    dates.push(slot.date);
                }
                byDate[slot.date].push(slot);
            });

            if (!dates.length) {
                slotsEl.textContent = 'Geen beschikbare tijden in deze periode.';
                return;
            }

            dates.forEach(function(date) {
                var group = el('div');
                group.style.marginBottom = '1rem';
                group.appendChild(el('strong', formatDate(date, {
                    weekday: 'long',
                    day: 'numeric',
                    month: 'long'
                })));
                var row = el('div');
                row.style.cssText = 'display:flex;flex-wrap:wrap;gap:0.5rem;margin-top:0.5rem;';
                byDate[date].forEach(function(slot) {
                    var button = el('button', slot.displayTime + (slot.practitionerName ? ' ' + slot.practitionerName : ''), 'elementor-button elementor-size-sm');
                    button.type = 'button';
                    button.addEventListener('click', function() {
                        chooseSlot(slot);
                    });
                    row.appendChild(button);
                });
                group.appendChild(row);
                slotsEl.appendChild(group);
            });
        }

        q('.vertimart-prev').addEventListener('click', function() {
            loadSlots(state.range.prev);
        });
        q('.vertimart-next').addEventListener('click', function() {
            loadSlots(state.range.next);
        });
        q('.vertimart-back-to-1').addEventListener('click', function() {
            message('', true);
            showStep(1);
        });

        // Step 3
        function chooseSlot(slot) {
            state.slot = slot;
            var summary = q('.vertimart-summary');
            summary.textContent = '';
            summary.appendChild(el('strong', state.typeName));
            [
                formatDate(slot.date, {
                    weekday: 'long',
                    day: 'numeric',
                    month: 'long',
                    year: 'numeric'
                }) + ' om ' + slot.displayTime,
                slot.practitionerName,
                slot.locationName
            ].forEach(function(line) {
                if (!line) return;
                summary.appendChild(el('br'));
                summary.appendChild(document.createTextNode(line));
            });
            message('', true);
            showStep(3);
        }

        q('.vertimart-back-to-2').addEventListener('click', function() {
            message('', true);
            showStep(2);
        });

        q('.vertimart-patient-form').addEventListener('submit', function(event) {
            event.preventDefault();
            var slot = state.slot;
            if (!slot) return;

            var body = {
                appointmentTypeId: state.typeId,
                startTime: slot.startTime,
                chairId: slot.chairId,
                practitionerId: slot.practitionerId,
                locationId: slot.locationId
            };
            new FormData(this).forEach(function(value, key) {
                body[key] = value;
            });

            var button = q('.vertimart-confirm');
            busy(button, true);
            post('vertimart_booking_confirm', body).then(function(res) {
                if (!res.success) {
                    message(res.message || 'De afspraak kon niet worden gemaakt.', false, res.errors);
                    return;
                }
                showStep(0);
                message('', true);
                var done = q('.vertimart-booking-done');
                done.style.cssText = 'border:2px solid #4CAF50;background:#f6fff6;color:#256029;padding:12px;border-radius:6px;';
                done.textContent = '';
                done.appendChild(el('strong', 'Afspraak bevestigd'));
                done.appendChild(el('br'));
                done.appendChild(document.createTextNode(state.typeName + ': ' + formatDate(slot.date, {
                    weekday: 'long',
                    day: 'numeric',
                    month: 'long'
                }) + ' om ' + slot.displayTime));
            }).catch(genericError).finally(function() {
                busy(button, false);
            });
        });
    })();
</script>
