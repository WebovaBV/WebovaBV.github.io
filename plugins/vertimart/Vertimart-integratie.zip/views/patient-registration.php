<?php
if (!defined('ABSPATH')) exit;

$locations = vertimartGetLocations();
$apiAvailable = count($locations) >= 1;
$feedback = vertimartReadRegistrationFeedback();
$idPrefix = wp_unique_id('vertimart-registration-');
$fields = vertimartPatientFields($bsnEnabled, $bsnRequired);
?>
<div>
    <?php if ($feedback): ?>
        <?php $isSuccess = $feedback['status'] === 'success'; ?>
        <div style="border: 2px solid <?= $isSuccess ? '#4CAF50' : '#f44336' ?>; background: <?= $isSuccess ? '#f6fff6' : '#fff6f6' ?>; color: <?= $isSuccess ? '#256029' : '#a12727' ?>; padding: 12px; border-radius: 6px; margin-bottom: 1rem;">
            <?= esc_html($feedback['message']) ?>
            <?php if ($feedback['errors']): ?>
                <ul style="margin: 0.5rem 0 0 1.25rem;">
                    <?php foreach ($feedback['errors'] as $error): ?>
                        <li><?= esc_html($error) ?></li>
                    <?php endforeach; ?>
                </ul>
            <?php endif; ?>
        </div>
    <?php endif; ?>
    <?php if (!$apiAvailable): ?>
        <div style="border: 2px solid #f44336; background: #fff6f6; color: #a12727; padding: 12px; border-radius: 6px; margin-bottom: 1rem;">
            Het registratieformulier is momenteel niet beschikbaar. Probeer het later opnieuw.
        </div>
    <?php endif; ?>
    <form method="post" action="<?= esc_url(admin_url('admin-post.php')) ?>">
        <?php wp_nonce_field('vertimart_registration_action', 'vertimart_registration_nonce'); ?>
        <input type="hidden" name="action" value="vertimart_registration_submit">
        <?php if ($bsnEnabled && $bsnRequired): ?>
            <input type="hidden" name="bsnRequired" value="1">
        <?php endif; ?>
        <fieldset <?= $apiAvailable ? '' : 'disabled' ?> style="border: 0; padding: 0; margin: 0; min-width: 0;">
            <div style="<?= count($locations) < 2 ? 'display:none;' : '' ?>" class="elementor-field-type-select elementor-field-group elementor-column elementor-col-100 elementor-field-required elementor-mark-required">
                <label for="<?= esc_attr($idPrefix . '-location') ?>" class="elementor-field-label" style="padding-top: 10px;padding-bottom: 3px;">Locatie</label>
                <select name="location" id="<?= esc_attr($idPrefix . '-location') ?>" class="elementor-field elementor-size-md elementor-field-textual" required="required">
                    <?php foreach ($locations as $location): ?>
                        <option value="<?= esc_attr((string) $location['id']) ?>"><?= esc_html($location['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <?php include VERTIMART_VIEWS_PATH . 'patient-fields.php'; ?>
            <div style="margin-top: 0.5rem;">
                <button class="elementor-button elementor-size-md" type="submit">Verzenden</button>
            </div>
        </fieldset>
    </form>
</div>
