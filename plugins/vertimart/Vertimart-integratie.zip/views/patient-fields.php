<?php
// Expects $idPrefix (unique per widget instance) and $fields (from vertimartPatientFields()).
if (!defined('ABSPATH')) exit;

foreach ($fields as $field):
    $id = $idPrefix . '-' . $field['name'];
    $groupClass = $field['required'] ? 'elementor-field-required elementor-mark-required' : '';
    $inputClass = 'elementor-field elementor-size-md elementor-field-textual';
?>
    <div class="elementor-field-type-text elementor-field-group elementor-column elementor-col-100 <?= esc_attr($groupClass) ?>">
        <label for="<?= esc_attr($id) ?>" class="elementor-field-label" style="padding-top: 10px;padding-bottom: 3px;"><?= esc_html($field['label']) ?></label>
        <?php if ($field['type'] === 'select'): ?>
            <select id="<?= esc_attr($id) ?>" name="<?= esc_attr($field['name']) ?>" class="<?= esc_attr($inputClass) ?>" <?= $field['required'] ? 'required="required"' : '' ?>>
                <option value="" disabled selected><?= esc_html($field['label']) ?></option>
                <?php foreach ($field['options'] as $value => $label): ?>
                    <option value="<?= esc_attr($value) ?>"><?= esc_html($label) ?></option>
                <?php endforeach; ?>
            </select>
        <?php else: ?>
            <input id="<?= esc_attr($id) ?>" name="<?= esc_attr($field['name']) ?>" type="<?= esc_attr($field['type']) ?>" class="<?= esc_attr($inputClass) ?>"
                autocomplete="<?= esc_attr($field['autocomplete'] ?? 'off') ?>"
                <?= !empty($field['max']) ? 'maxlength="' . esc_attr((string) $field['max']) . '"' : '' ?>
                <?= !empty($field['pattern']) ? 'pattern="' . esc_attr($field['pattern']) . '"' : '' ?>
                <?= $field['required'] ? 'required="required"' : '' ?>>
        <?php endif; ?>
    </div>
<?php endforeach; ?>

<?php foreach (vertimartPatientConsents() as $name => $consent): ?>
    <div class="elementor-field-type-checkbox elementor-field-group elementor-column elementor-col-100" style="padding-top: 8px;">
        <label for="<?= esc_attr($idPrefix . '-' . $name) ?>">
            <input type="checkbox" id="<?= esc_attr($idPrefix . '-' . $name) ?>" name="<?= esc_attr($name) ?>" value="1" <?= checked($consent['checked'], true, false) ?>>
            <?= esc_html($consent['label']) ?>
        </label>
    </div>
<?php endforeach; ?>
