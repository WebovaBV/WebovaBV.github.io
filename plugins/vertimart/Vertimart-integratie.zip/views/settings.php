<?php
if (!defined('ABSPATH')) exit;

$licenceId = get_option('vertimart_licence_id', '');
$hasKey = get_option('vertimart_subscription_key', '') !== '';
$countryCode = vertimartCountryCode();
$appointmentTypes = vertimartGetAppointmentTypes();
$testResult = get_transient('vertimart_test_result');
delete_transient('vertimart_test_result');
?>
<div class="wrap">
    <h1>Vertimart Integratie Instellingen</h1>
    <form method="post" action="options.php">
        <div>
            <h3>Verbinding</h3>
            <div style="padding-bottom: 1rem; margin-left:2rem;">
                <p class="description">Voer hier de gegevens in die u van Vertimart heeft ontvangen.</p>
                <p>
                    <label for="vertimart_licence_id"><b>Licentie-ID</b></label><br>
                    <input type="text" id="vertimart_licence_id" name="vertimart_licence_id" value="<?= esc_attr($licenceId) ?>" size="60" placeholder="Exquise licentie-ID" />
                </p>
                <p>
                    <label for="vertimart_subscription_key"><b>Subscription key</b></label><br>
                    <input type="password" id="vertimart_subscription_key" name="vertimart_subscription_key" value="" size="60" autocomplete="new-password"
                        placeholder="<?= $hasKey ? 'Ingesteld (laat leeg om te behouden)' : 'Subscription key' ?>" />
                </p>
                <a href="<?= esc_url(wp_nonce_url(admin_url('admin-post.php?action=vertimart_test_connection'), 'vertimart_test_connection_action')) ?>" class="button button-secondary">Test API verbinding</a>
                <?php if (is_array($testResult)): ?>
                    <?php if ($testResult['ok']): ?>
                        <div class="notice notice-success inline" style="margin:1rem 0;">
                            <p>Verbinding gelukt. Er zijn <?= count($testResult['locations']) ?> locatie(s) gevonden.</p>
                        </div>
                        <?php if ($testResult['locations']): ?>
                            <table class="widefat striped" style="max-width:40rem;">
                                <thead>
                                    <tr><th>ID</th><th>Naam</th><th>Plaats</th></tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($testResult['locations'] as $location): ?>
                                        <tr>
                                            <td><?= esc_html((string) ($location['Id'] ?? '')) ?></td>
                                            <td><?= esc_html((string) ($location['Name'] ?? '')) ?></td>
                                            <td><?= esc_html((string) ($location['Address']['City'] ?? '')) ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        <?php endif; ?>
                    <?php else: ?>
                        <div class="notice notice-warning inline" style="margin:1rem 0;">
                            <p>Geen verbinding met de Vertimart API. Controleer het licentie-ID en de subscription key.</p>
                        </div>
                        <?php if ($testResult['error'] !== ''): ?>
                            <pre style="max-width:40rem; max-height:20rem; overflow:auto; padding:0.75rem; background:#f6f7f7; border:1px solid #dcdcde; white-space:pre-wrap; word-break:break-word;"><?= esc_html($testResult['error']) ?></pre>
                        <?php endif; ?>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>

        <div>
            <h3>Afspraaktypes</h3>
            <div style="padding-bottom: 1rem; margin-left:2rem;">
                <p class="description">De API biedt geen lijst met afspraaktypes. Voeg ze hier toe met de naam die bezoekers zien en het bijbehorende AppointmentTypeId.</p>
                <table class="widefat striped" style="max-width:40rem;">
                    <thead>
                        <tr><th>Naam</th><th>AppointmentTypeId</th><th></th></tr>
                    </thead>
                    <tbody id="vertimart-types"></tbody>
                </table>
                <p><button type="button" class="button" id="vertimart-add-type">Afspraaktype toevoegen</button></p>
            </div>
        </div>

        <div>
            <h3>Land</h3>
            <div style="padding-bottom: 1rem; margin-left:2rem;">
                <p class="description">ISO 3166-1 landnummer dat wordt meegestuurd bij registraties. Nederland is 528.</p>
                <input type="number" min="1" name="vertimart_default_country_code" value="<?= esc_attr((string) $countryCode) ?>" />
            </div>
        </div>
        <?php settings_fields('vertimart_options'); submit_button(); ?>
    </form>
    <hr>
    <div>
        <h3>Cache</h3>
        <?php if (isset($_GET['vertimart_cache_cleared'])): ?>
            <div class="notice notice-success is-dismissible">
                <p>De cache van deze plugin is geleegd.</p>
            </div>
        <?php endif; ?>
        <div style="padding-bottom: 1rem; margin-left:2rem;">
            <p class="description">Leeg de gecachete locaties en beschikbare tijden van deze plugin. Doe dit na het wijzigen van de verbindingsgegevens of als gegevens verouderd lijken.</p>
            <form method="post" action="<?= esc_url(admin_url('admin-post.php')) ?>">
                <input type="hidden" name="action" value="vertimart_clear_cache">
                <?php wp_nonce_field('vertimart_clear_cache_action', 'vertimart_clear_cache_nonce'); ?>
                <?php submit_button('Cache legen', 'secondary', 'submit', false); ?>
            </form>
        </div>
    </div>
    <hr>
    <div>
        <h3>Debug</h3>
        <div style="margin-left:2rem;">
            <b>Debug modus:</b> <small><?= WP_DEBUG ? 'Aan' : 'Uit' ?></small><br>
            <b>Timezone:</b> <small><?= esc_html(wp_timezone()->getName()) ?></small><br>
            <b>API URL:</b> <small><?= esc_html(VERTIMART_API_URL) ?></small><br>
        </div>
    </div>
</div>
<script>
    (function() {
        var body = document.getElementById('vertimart-types');
        var index = 0;

        function addRow(name, id) {
            var row = document.createElement('tr');
            [
                ['name', 'text', name],
                ['id', 'number', id]
            ].forEach(function(spec) {
                var cell = document.createElement('td');
                var input = document.createElement('input');
                input.type = spec[1];
                input.name = 'vertimart_appointment_types[' + index + '][' + spec[0] + ']';
                input.value = spec[2];
                if (spec[1] === 'number') input.min = 1;
                cell.appendChild(input);
                row.appendChild(cell);
            });
            var actions = document.createElement('td');
            var remove = document.createElement('button');
            remove.type = 'button';
            remove.className = 'button-link-delete';
            remove.textContent = 'Verwijderen';
            remove.addEventListener('click', function() {
                row.remove();
            });
            actions.appendChild(remove);
            row.appendChild(actions);
            body.appendChild(row);
            index++;
        }

        var types = <?= wp_json_encode($appointmentTypes) ?>;
        types.forEach(function(type) {
            addRow(type.name, type.id);
        });
        if (!types.length) addRow('', '');
        document.getElementById('vertimart-add-type').addEventListener('click', function() {
            addRow('', '');
        });
    })();
</script>
