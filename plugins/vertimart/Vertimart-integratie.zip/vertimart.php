<?php
/*
Plugin Name: Vertimart integratie
Text Domain: vertimart-integratie
Description: Maakt een API-koppeling tussen Vertimart en Webova Nederland B.V. voor patiëntregistratie en online afspraakplanning.
Version: 1.0.0
Author: Webova Nederland B.V.
Requires Plugins: elementor
Requires PHP: 8.1
Requires at least: 7.0.2
Tested up to: 7.1
Plugin URI: https://github.com/WebovaBV/Vertimart-wordpress/releases
Author URI: https://Webova.nl
*/
if (!defined('ABSPATH')) exit;

define('VERTIMART_PLUGIN_FILE', __FILE__);
define('VERTIMART_VIEWS_PATH', plugin_dir_path(__FILE__) . 'views/');
define('VERTIMART_INCLUDES_PATH', plugin_dir_path(__FILE__) . 'includes/');

// Override in wp-config.php to point at the production API.
if (!defined('VERTIMART_API_URL')) {
    define('VERTIMART_API_URL', 'https://api.vertimart.nl/patient-registration-test/v1');
}

include_once VERTIMART_INCLUDES_PATH . 'plugin-updater.php';
include_once VERTIMART_INCLUDES_PATH . 'core.php';
include_once VERTIMART_INCLUDES_PATH . 'patient.php';
include_once VERTIMART_INCLUDES_PATH . 'plugin-settings.php';
include_once VERTIMART_INCLUDES_PATH . 'plugin-uninstall.php';
include_once VERTIMART_INCLUDES_PATH . 'widget/patient-registration.php';
include_once VERTIMART_INCLUDES_PATH . 'widget/appointment-booking.php';

register_uninstall_hook(VERTIMART_PLUGIN_FILE, 'vertimartUninstall');
