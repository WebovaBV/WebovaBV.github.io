<?php
// Patient form fields shared by the registration and booking widgets:
// the views render them and the readers below validate and map them to the API payload.

if (!defined('ABSPATH')) exit;

function vertimartGenderOptions(): array
{
    return [
        'Male' => 'Man',
        'Female' => 'Vrouw',
        'Nonbinary' => 'Non-binair',
        'Undefined' => 'Onbekend',
    ];
}

function vertimartPatientFields(bool $bsnEnabled = false, bool $bsnRequired = false): array
{
    $fields = [
        ['name' => 'firstName', 'api' => 'FirstName', 'label' => 'Voornaam', 'type' => 'text', 'max' => 25, 'required' => true, 'autocomplete' => 'given-name'],
        ['name' => 'prefix', 'api' => 'Prefix', 'label' => 'Tussenvoegsel', 'type' => 'text', 'max' => 10, 'required' => false, 'autocomplete' => 'off'],
        ['name' => 'lastName', 'api' => 'LastName', 'label' => 'Achternaam', 'type' => 'text', 'max' => 60, 'required' => true, 'autocomplete' => 'family-name'],
        ['name' => 'initials', 'api' => 'Initials', 'label' => 'Initialen', 'type' => 'text', 'max' => 11, 'required' => true, 'autocomplete' => 'off'],
        ['name' => 'dateOfBirth', 'api' => 'DateOfBirth', 'label' => 'Geboortedatum', 'type' => 'date', 'required' => true, 'autocomplete' => 'bday'],
        ['name' => 'gender', 'api' => 'Gender', 'label' => 'Geslacht', 'type' => 'select', 'options' => vertimartGenderOptions(), 'required' => true],
        ['name' => 'street', 'api' => 'StreetName', 'label' => 'Straat', 'type' => 'text', 'max' => 50, 'required' => true, 'autocomplete' => 'address-line1'],
        ['name' => 'houseNumber', 'api' => 'HouseNumber', 'label' => 'Huisnummer (met toevoeging)', 'type' => 'text', 'max' => 9, 'required' => true, 'autocomplete' => 'off'],
        ['name' => 'zipCode', 'api' => 'ZipCode', 'label' => 'Postcode', 'type' => 'text', 'max' => 7, 'required' => true, 'autocomplete' => 'postal-code'],
        ['name' => 'city', 'api' => 'PlaceName', 'label' => 'Woonplaats', 'type' => 'text', 'max' => 50, 'required' => true, 'autocomplete' => 'address-level2'],
        ['name' => 'phone', 'api' => null, 'label' => 'Telefoon', 'type' => 'tel', 'max' => 25, 'required' => true, 'autocomplete' => 'tel'],
        ['name' => 'email', 'api' => null, 'label' => 'E-mail', 'type' => 'email', 'max' => 254, 'required' => true, 'autocomplete' => 'email'],
    ];

    if ($bsnEnabled) {
        $fields[] = ['name' => 'bsn', 'api' => 'Bsn', 'label' => 'BSN (Burgerservicenummer)', 'type' => 'text', 'max' => 9, 'required' => $bsnRequired, 'autocomplete' => 'off', 'pattern' => '[0-9]{9}'];
    }

    return $fields;
}

function vertimartPatientConsents(): array
{
    return [
        'receiveSystemMail' => ['label' => 'Ik ontvang graag e-mails over mijn afspraken en behandeling', 'checked' => true],
        'receiveNewsletters' => ['label' => 'Ik ontvang graag de nieuwsbrief', 'checked' => false],
        'receiveSms' => ['label' => 'Ik ontvang graag sms-berichten', 'checked' => false],
    ];
}

function vertimartPatientFieldError(array $field, string $value): ?string
{
    $label = $field['label'];

    if (!empty($field['max']) && mb_strlen($value) > $field['max']) {
        return "$label mag maximaal {$field['max']} tekens bevatten.";
    }

    return match ($field['name']) {
        'email' => is_email($value) ? null : 'Het e-mailadres is ongeldig.',
        'gender' => isset(vertimartGenderOptions()[$value]) ? null : 'Kies een geldig geslacht.',
        'bsn' => preg_match('/^[0-9]{9}$/', $value) ? null : 'Het BSN moet uit 9 cijfers bestaan.',
        'dateOfBirth' => vertimartValidDateOfBirth($value) ? null : 'De geboortedatum is ongeldig.',
        default => null,
    };
}

function vertimartValidDateOfBirth(string $value): bool
{
    $date = DateTimeImmutable::createFromFormat('!Y-m-d', $value, wp_timezone());
    return $date && $date->format('Y-m-d') === $value && $date <= new DateTimeImmutable('today', wp_timezone());
}

function vertimartReadText(array $input, string $name): string
{
    $raw = $input[$name] ?? '';
    return is_string($raw) ? trim(sanitize_text_field(wp_unslash($raw))) : '';
}

function vertimartReadFlag(array $input, string $name): bool
{
    return !empty($input[$name]);
}

// Returns ['payload' => array|null, 'errors' => string[]].
function vertimartReadPatientInput(array $input, bool $bsnEnabled, bool $bsnRequired): array
{
    $values = [];
    $errors = [];

    foreach (vertimartPatientFields($bsnEnabled, $bsnRequired) as $field) {
        $value = vertimartReadText($input, $field['name']);
        if ($value === '') {
            if ($field['required']) {
                $errors[] = "{$field['label']} is verplicht.";
            }
            continue;
        }
        $error = vertimartPatientFieldError($field, $value);
        if ($error) {
            $errors[] = $error;
            continue;
        }
        $values[$field['name']] = $value;
    }

    if ($errors) {
        return ['payload' => null, 'errors' => $errors];
    }

    $payload = ['CountryCode' => vertimartCountryCode()];
    foreach (vertimartPatientFields($bsnEnabled, $bsnRequired) as $field) {
        if ($field['api'] && isset($values[$field['name']])) {
            $payload[$field['api']] = $values[$field['name']];
        }
    }

    $payload['Email'] = [
        'EmailAddress' => $values['email'],
        'ReceiveSystemMail' => vertimartReadFlag($input, 'receiveSystemMail'),
        'ReceiveNewsletters' => vertimartReadFlag($input, 'receiveNewsletters'),
    ];
    $payload['Phone'] = [
        'PhoneNumber' => $values['phone'],
        'ReceiveSms' => vertimartReadFlag($input, 'receiveSms'),
    ];

    return ['payload' => $payload, 'errors' => []];
}
