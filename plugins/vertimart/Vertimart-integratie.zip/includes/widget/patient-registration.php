<?php
if (!defined('ABSPATH')) exit;

class VertimartPatientRegistration extends WP_Widget
{
    public function __construct()
    {
        parent::__construct(
            'vertimart_patient_registration',
            __('Vertimart Patiëntenregistratie', 'vertimart-integratie'),
            ['customize_selective_refresh' => false]
        );
    }

    public function widget($args, $instance)
    {
        $bsnEnabled = ($instance['bsnEnabled'] ?? 'off') === 'on';
        $bsnRequired = ($instance['bsnRequired'] ?? 'off') === 'on';
        include VERTIMART_VIEWS_PATH . 'patient-registration.php';
    }

    public function form($instance)
    {
        $bsnEnabled = ($instance['bsnEnabled'] ?? 'off') === 'on';
        $bsnRequired = ($instance['bsnRequired'] ?? 'off') === 'on';
        include VERTIMART_VIEWS_PATH . 'form/patient-options.php';
    }

    public function update($newInstance, $oldInstance)
    {
        return [
            'bsnEnabled' => ($newInstance['bsnEnabled'] ?? 'off') === 'on' ? 'on' : 'off',
            'bsnRequired' => ($newInstance['bsnRequired'] ?? 'off') === 'on' ? 'on' : 'off',
        ];
    }
}

function vertimartRegisterRegistrationWidget()
{
    register_widget('VertimartPatientRegistration');
}

// The redirect carries only a status; messages live in a short-lived transient behind a random reference.
function vertimartRedirectWithFeedback(string $back, string $status, array $feedback = []): never
{
    $args = ['vertimart_status' => $status];
    if ($feedback) {
        $ref = wp_generate_password(12, false);
        set_transient('vertimart_feedback_' . $ref, $feedback, 5 * MINUTE_IN_SECONDS);
        $args['vertimart_ref'] = $ref;
    }
    wp_safe_redirect(add_query_arg($args, $back));
    exit;
}

function vertimartReadRegistrationFeedback(): ?array
{
    $status = isset($_GET['vertimart_status']) && is_string($_GET['vertimart_status'])
        ? sanitize_key(wp_unslash($_GET['vertimart_status']))
        : '';
    if (!in_array($status, ['success', 'error'], true)) {
        return null;
    }

    $feedback = [
        'status' => $status,
        'message' => $status === 'success'
            ? 'Bedankt! Uw registratie is verzonden.'
            : 'Er is een fout opgetreden bij het registreren. Probeer het later opnieuw.',
        'errors' => [],
    ];

    $ref = isset($_GET['vertimart_ref']) && is_string($_GET['vertimart_ref'])
        ? preg_replace('/[^a-zA-Z0-9]/', '', wp_unslash($_GET['vertimart_ref']))
        : '';
    $stored = $ref !== '' ? get_transient('vertimart_feedback_' . $ref) : false;
    if ($status === 'error' && is_array($stored)) {
        $feedback['message'] = (string) ($stored['message'] ?? $feedback['message']);
        $feedback['errors'] = array_map('strval', (array) ($stored['errors'] ?? []));
    }

    return $feedback;
}

function vertimartHandleRegistrationSubmit()
{
    $back = remove_query_arg(['vertimart_status', 'vertimart_ref'], wp_get_referer() ?: home_url('/'));

    $nonce = sanitize_text_field(wp_unslash($_POST['vertimart_registration_nonce'] ?? ''));
    if (!wp_verify_nonce($nonce, 'vertimart_registration_action')) {
        vertimartRedirectWithFeedback($back, 'error', ['message' => 'De sessie is verlopen. Ververs de pagina en probeer het opnieuw.']);
    }

    $locationId = absint($_POST['location'] ?? 0);
    if (!in_array($locationId, array_column(vertimartGetLocations(), 'id'), true)) {
        vertimartRedirectWithFeedback($back, 'error', ['message' => 'Kies een geldige locatie.']);
    }

    $patient = vertimartReadPatientInput($_POST, isset($_POST['bsn']), !empty($_POST['bsnRequired']));
    if ($patient['errors']) {
        vertimartRedirectWithFeedback($back, 'error', ['message' => 'Controleer de ingevulde gegevens.', 'errors' => $patient['errors']]);
    }

    $payload = $patient['payload'] + ['LocationId' => $locationId];
    $response = vertimartSubmitRegistration($payload);
    if (!$response['success']) {
        vertimartRedirectWithFeedback($back, 'error', ['message' => $response['message'], 'errors' => $response['errors']]);
    }

    vertimartRedirectWithFeedback($back, 'success');
}

add_action('widgets_init', 'vertimartRegisterRegistrationWidget');
add_action('admin_post_nopriv_vertimart_registration_submit', 'vertimartHandleRegistrationSubmit');
add_action('admin_post_vertimart_registration_submit', 'vertimartHandleRegistrationSubmit');
