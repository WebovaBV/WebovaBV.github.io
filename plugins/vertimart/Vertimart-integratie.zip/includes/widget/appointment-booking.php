<?php
if (!defined('ABSPATH')) exit;

const VERTIMART_BOOKING_WINDOW_DAYS = 14;
const VERTIMART_REMARK_MAX_LENGTH = 300;

class VertimartAppointmentBooking extends WP_Widget
{
    public function __construct()
    {
        parent::__construct(
            'vertimart_appointment_booking',
            __('Vertimart Afspraak maken', 'vertimart-integratie'),
            ['customize_selective_refresh' => false]
        );
    }

    public function widget($args, $instance)
    {
        $bsnEnabled = ($instance['bsnEnabled'] ?? 'off') === 'on';
        $bsnRequired = ($instance['bsnRequired'] ?? 'off') === 'on';
        include VERTIMART_VIEWS_PATH . 'appointment-booking.php';
    }

    public function form($instance)
    {
        $bsnEnabled = ($instance['bsnEnabled'] ?? 'off') === 'on';
        $bsnRequired = ($instance['bsnRequired'] ?? 'off') === 'on';
        include VERTIMART_VIEWS_PATH . 'form/patient-options.php';
    }

    public function update($newInstance, $oldInstance)
    {
        return [
            'bsnEnabled' => ($newInstance['bsnEnabled'] ?? 'off') === 'on' ? 'on' : 'off',
            'bsnRequired' => ($newInstance['bsnRequired'] ?? 'off') === 'on' ? 'on' : 'off',
        ];
    }
}

function vertimartRegisterBookingWidget()
{
    register_widget('VertimartAppointmentBooking');
}

function vertimartVerifyBookingRequest()
{
    check_ajax_referer('vertimart_booking', 'nonce');
}

function vertimartBookingFail(string $message, array $errors = []): never
{
    wp_send_json(['success' => false, 'message' => $message, 'errors' => $errors]);
}

function vertimartBookingType(): array
{
    $type = vertimartFindAppointmentType(absint($_POST['appointmentTypeId'] ?? 0));
    if (!$type) {
        vertimartBookingFail('Kies een geldig type afspraak.');
    }
    return $type;
}

function vertimartHandleBookingSlots()
{
    vertimartVerifyBookingRequest();
    $type = vertimartBookingType();

    $timezone = wp_timezone();
    $today = new DateTimeImmutable('today', $timezone);
    $from = DateTimeImmutable::createFromFormat('!Y-m-d', vertimartReadText($_POST, 'from'), $timezone);
    if (!$from || $from < $today || $from > $today->modify('+1 year')) {
        $from = $today;
    }
    $to = $from->modify('+' . VERTIMART_BOOKING_WINDOW_DAYS . ' days');
    $prev = $from > $today ? max($today, $from->modify('-' . VERTIMART_BOOKING_WINDOW_DAYS . ' days')) : null;

    $result = vertimartGetAvailableSlots($type['id'], $from, $to);
    if (!$result['ok']) {
        vertimartBookingFail($result['message']);
    }

    wp_send_json([
        'success' => true,
        'slots' => $result['slots'],
        'from' => $from->format('Y-m-d'),
        'to' => $to->format('Y-m-d'),
        'prev' => $prev ? $prev->format('Y-m-d') : '',
        'next' => $to->format('Y-m-d'),
    ]);
}

function vertimartHandleBookingConfirm()
{
    vertimartVerifyBookingRequest();
    $type = vertimartBookingType();

    $patient = vertimartReadPatientInput($_POST, isset($_POST['bsn']), !empty($_POST['bsnRequired']));
    if ($patient['errors']) {
        vertimartBookingFail('Controleer de ingevulde gegevens.', $patient['errors']);
    }

    $startTime = vertimartReadText($_POST, 'startTime');
    if (!vertimartLocalDateTime($startTime)) {
        vertimartBookingFail('Kies een geldig tijdstip.');
    }

    $appointment = [
        'AppointmentTypeId' => $type['id'],
        'StartTime' => $startTime,
        'ChairId' => absint($_POST['chairId'] ?? 0),
        'PracticionerId' => absint($_POST['practitionerId'] ?? 0),
    ];
    $remark = mb_substr(sanitize_textarea_field(wp_unslash($_POST['remark'] ?? '')), 0, VERTIMART_REMARK_MAX_LENGTH);
    if ($remark !== '') {
        $appointment['Remark'] = $remark;
    }

    $payload = $patient['payload'] + ['Appointment' => $appointment];
    $locationId = absint($_POST['locationId'] ?? 0);
    if ($locationId) {
        $payload['LocationId'] = $locationId;
    }

    $response = vertimartSubmitRegistration($payload);
    if (!$response['success']) {
        vertimartBookingFail($response['message'], $response['errors']);
    }

    wp_send_json(['success' => true]);
}

add_action('widgets_init', 'vertimartRegisterBookingWidget');

foreach ([
    'vertimart_booking_slots' => 'vertimartHandleBookingSlots',
    'vertimart_booking_confirm' => 'vertimartHandleBookingConfirm',
] as $action => $handler) {
    add_action("wp_ajax_$action", $handler);
    add_action("wp_ajax_nopriv_$action", $handler);
}
