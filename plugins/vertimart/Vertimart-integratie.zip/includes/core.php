<?php
if (!defined('ABSPATH')) exit;

const VERTIMART_CACHE_TTL = 1800;
const VERTIMART_SLOTS_CACHE_TTL = 60;
const VERTIMART_DEFAULT_COUNTRY_CODE = 528;

function vertimartResult(bool $ok, int $status, mixed $data, string $message = '', array $errors = [], string $debug = ''): array
{
    return [
        'ok' => $ok,
        'status' => $status,
        'data' => $data,
        'message' => $message,
        'errors' => $errors,
        'debug' => $debug,
    ];
}

function vertimartStatusMessage(int $status): string
{
    return match (true) {
        $status === 400 => 'De ingevoerde gegevens zijn niet geldig.',
        $status === 401, $status === 403 => 'De koppeling met Vertimart is niet correct ingesteld. Neem contact op met de praktijk.',
        $status === 424 => 'De gegevens konden niet worden gecontroleerd. Probeer het later opnieuw.',
        default => 'De service is momenteel niet beschikbaar. Probeer het later opnieuw.',
    };
}

// Flattens the ProblemDetails "Errors" map (field => messages) into a list of lines.
function vertimartValidationErrors(mixed $data): array
{
    if (!is_array($data) || empty($data['Errors']) || !is_array($data['Errors'])) {
        return [];
    }
    $lines = [];
    foreach ($data['Errors'] as $field => $messages) {
        foreach ((array) $messages as $message) {
            $lines[] = sanitize_text_field("$field: $message");
        }
    }
    return $lines;
}

function vertimartRequest(string $method, string $path, array $query = [], ?array $body = null): array
{
    $url = VERTIMART_API_URL . $path;
    if ($query) {
        $url .= '?' . http_build_query($query, '', '&', PHP_QUERY_RFC3986);
    }

    $args = [
        'method' => $method,
        'timeout' => 15,
        'headers' => [
            'Accept' => 'application/json',
            'subscription-key' => (string) get_option('vertimart_subscription_key', ''),
            'licence-id' => (string) get_option('vertimart_licence_id', ''),
        ],
    ];
    if ($body !== null) {
        $args['headers']['Content-Type'] = 'application/json';
        $args['body'] = wp_json_encode($body);
    }

    $response = wp_remote_request($url, $args);
    if (is_wp_error($response)) {
        return vertimartResult(false, 0, null, vertimartStatusMessage(0), [], "$method $url\n" . $response->get_error_message());
    }

    $status = (int) wp_remote_retrieve_response_code($response);
    $raw = wp_remote_retrieve_body($response);
    $data = json_decode($raw, true);

    if ($status >= 200 && $status < 300) {
        return vertimartResult(true, $status, $data);
    }

    $errors = $status === 400 ? vertimartValidationErrors($data) : [];
    return vertimartResult(false, $status, $data, vertimartStatusMessage($status), $errors, "$method $url\nHTTP $status\n\n$raw");
}

function vertimartCacheKey(string $name, array $args = []): string
{
    $version = (int) get_option('vertimart_cache_version', 1);
    return "vertimart_{$name}_{$version}" . ($args ? '_' . md5(wp_json_encode($args)) : '');
}

// Bumping the version orphans every cached entry, which then expires on its own.
function vertimartClearCache(): void
{
    update_option('vertimart_cache_version', (int) get_option('vertimart_cache_version', 1) + 1, false);
}

add_action('update_option_vertimart_subscription_key', 'vertimartClearCache');
add_action('update_option_vertimart_licence_id', 'vertimartClearCache');

function vertimartCountryCode(): int
{
    return absint(get_option('vertimart_default_country_code', VERTIMART_DEFAULT_COUNTRY_CODE)) ?: VERTIMART_DEFAULT_COUNTRY_CODE;
}

// Configured on the settings page, the API has no endpoint to list them.
function vertimartGetAppointmentTypes(): array
{
    $types = get_option('vertimart_appointment_types', []);
    return is_array($types) ? array_values($types) : [];
}

function vertimartFindAppointmentType(int $id): ?array
{
    foreach (vertimartGetAppointmentTypes() as $type) {
        if ((int) $type['id'] === $id) {
            return $type;
        }
    }
    return null;
}

function vertimartGetLocations(): array
{
    $key = vertimartCacheKey('locations');
    $cached = get_transient($key);
    if (is_array($cached)) {
        return $cached;
    }

    $result = vertimartRequest('GET', '/locations');
    if (!$result['ok'] || !is_array($result['data'])) {
        return [];
    }

    $locations = array_values(array_map(fn($location) => [
        'id' => (int) ($location['Id'] ?? 0),
        'name' => (string) ($location['Name'] ?? ''),
        'city' => (string) ($location['Address']['City'] ?? ''),
    ], $result['data']));

    if ($locations) {
        set_transient($key, $locations, VERTIMART_CACHE_TTL);
    }
    return $locations;
}

function vertimartLocalDateTime(string $value): ?DateTimeImmutable
{
    try {
        return (new DateTimeImmutable($value, wp_timezone()))->setTimezone(wp_timezone());
    } catch (Exception) {
        return null;
    }
}

// Joins each timeslot with its practitioner and (via the chair) its location.
function vertimartBuildSlots(array $data): array
{
    $practitioners = array_column($data['Practitioners'] ?? [], 'Name', 'Id');
    $locations = array_column($data['Locations'] ?? [], 'Name', 'Id');
    $chairLocations = array_column($data['Chairs'] ?? [], 'LocationId', 'ChairId');

    $slots = [];
    foreach ($data['Timeslots'] ?? [] as $timeslot) {
        $raw = (string) ($timeslot['StartDateTime'] ?? '');
        $start = vertimartLocalDateTime($raw);
        if (!$start) {
            continue;
        }
        $chairId = (int) ($timeslot['ChairId'] ?? 0);
        $practitionerId = (int) ($timeslot['PractitionerId'] ?? 0);
        $locationId = (int) ($chairLocations[$chairId] ?? 0);
        $slots[] = [
            'startTime' => $raw,
            'timestamp' => $start->getTimestamp(),
            'date' => $start->format('Y-m-d'),
            'displayTime' => $start->format('H:i'),
            'practitionerId' => $practitionerId,
            'practitionerName' => (string) ($practitioners[$practitionerId] ?? ''),
            'chairId' => $chairId,
            'locationId' => $locationId,
            'locationName' => (string) ($locations[$locationId] ?? ''),
        ];
    }

    usort($slots, fn($a, $b) => $a['timestamp'] <=> $b['timestamp']);
    return $slots;
}

function vertimartGetAvailableSlots(int $appointmentTypeId, DateTimeImmutable $start, DateTimeImmutable $end): array
{
    $query = [
        'AppointmentTypeId' => $appointmentTypeId,
        'StartDateTime' => $start->format('c'),
        'EndDateTime' => $end->format('c'),
    ];

    $key = vertimartCacheKey('slots', $query);
    $cached = get_transient($key);
    if (is_array($cached)) {
        return ['ok' => true, 'slots' => $cached, 'message' => ''];
    }

    $result = vertimartRequest('GET', '/availabletime', $query);
    if (!$result['ok']) {
        return ['ok' => false, 'slots' => [], 'message' => $result['message']];
    }

    $slots = vertimartBuildSlots(is_array($result['data']) ? $result['data'] : []);
    set_transient($key, $slots, VERTIMART_SLOTS_CACHE_TTL);
    return ['ok' => true, 'slots' => $slots, 'message' => ''];
}

function vertimartSubmitRegistration(array $payload): array
{
    $result = vertimartRequest('POST', '/patientregistration/naw', [], $payload);
    if (!$result['ok']) {
        return ['success' => false, 'message' => $result['message'], 'errors' => $result['errors']];
    }
    return [
        'success' => true,
        'registrationId' => (int) ($result['data']['PatientRegistrationId'] ?? 0),
        'message' => '',
        'errors' => [],
    ];
}

function vertimartTestConnection(): array
{
    $result = vertimartRequest('GET', '/locations');
    return [
        'ok' => $result['ok'],
        'locations' => $result['ok'] && is_array($result['data']) ? $result['data'] : [],
        'error' => $result['ok'] ? '' : ($result['debug'] ?: $result['message']),
    ];
}
