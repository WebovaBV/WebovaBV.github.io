<?php
if (!defined('ABSPATH')) exit;

add_action('admin_menu', function () {
    add_options_page('Vertimart Integratie Instellingen', 'Vertimart', 'manage_options', 'vertimart', 'vertimartSettingsPage');
});

function vertimartSettingsPage()
{
    include VERTIMART_VIEWS_PATH . 'settings.php';
}

function vertimartSettingsUrl(): string
{
    return admin_url('options-general.php?page=vertimart');
}

function vertimartRequireAdmin(): void
{
    if (!current_user_can('manage_options')) {
        wp_die('Onvoldoende rechten.', 403);
    }
}

add_action('admin_post_vertimart_clear_cache', 'vertimartHandleClearCache');
function vertimartHandleClearCache()
{
    vertimartRequireAdmin();
    check_admin_referer('vertimart_clear_cache_action', 'vertimart_clear_cache_nonce');
    vertimartClearCache();
    wp_safe_redirect(add_query_arg('vertimart_cache_cleared', '1', vertimartSettingsUrl()));
    exit;
}

add_action('admin_post_vertimart_test_connection', 'vertimartHandleTestConnection');
function vertimartHandleTestConnection()
{
    vertimartRequireAdmin();
    check_admin_referer('vertimart_test_connection_action');
    vertimartClearCache();
    set_transient('vertimart_test_result', vertimartTestConnection(), 60);
    wp_safe_redirect(vertimartSettingsUrl());
    exit;
}

// An empty submit keeps the stored key, so it never has to be printed back into the form.
function vertimartSanitizeSubscriptionKey($value)
{
    $value = sanitize_text_field((string) $value);
    return $value !== '' ? $value : get_option('vertimart_subscription_key', '');
}

function vertimartSanitizeAppointmentTypes($value)
{
    if (!is_array($value)) {
        return [];
    }

    $types = [];
    foreach ($value as $row) {
        $name = sanitize_text_field($row['name'] ?? '');
        $id = absint($row['id'] ?? 0);
        if ($name !== '' && $id > 0) {
            $types[] = ['name' => $name, 'id' => $id];
        }
    }
    return $types;
}

function vertimartSanitizeCountryCode($value)
{
    return absint($value) ?: VERTIMART_DEFAULT_COUNTRY_CODE;
}

add_action('admin_init', function () {
    register_setting('vertimart_options', 'vertimart_subscription_key', ['sanitize_callback' => 'vertimartSanitizeSubscriptionKey']);
    register_setting('vertimart_options', 'vertimart_licence_id', ['sanitize_callback' => 'sanitize_text_field']);
    register_setting('vertimart_options', 'vertimart_appointment_types', ['sanitize_callback' => 'vertimartSanitizeAppointmentTypes']);
    register_setting('vertimart_options', 'vertimart_default_country_code', ['sanitize_callback' => 'vertimartSanitizeCountryCode']);
});
