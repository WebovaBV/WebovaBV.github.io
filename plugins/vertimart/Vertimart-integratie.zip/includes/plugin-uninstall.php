<?php
if (!defined('ABSPATH')) exit;

function vertimartUninstall(): void
{
    global $wpdb;

    foreach ([
        'vertimart_subscription_key',
        'vertimart_licence_id',
        'vertimart_appointment_types',
        'vertimart_default_country_code',
        'vertimart_cache_version',
    ] as $option) {
        delete_option($option);
    }

    $wpdb->query($wpdb->prepare(
        "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s",
        $wpdb->esc_like('_transient_vertimart_') . '%',
        $wpdb->esc_like('_transient_timeout_vertimart_') . '%'
    ));
}
