<?php
register_uninstall_hook(__FILE__, 'zorgform_loader_uninstall');
function zorgform_loader_uninstall()
{
    delete_option('zorgform_loader_practice_key');
    delete_option('zorgform_loader_texts');
}
