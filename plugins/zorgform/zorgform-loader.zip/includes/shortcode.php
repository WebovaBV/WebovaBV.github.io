<?php
if ( !defined( 'ABSPATH' ) ) exit;

add_shortcode('zorgform', 'zorgform_render_shortcode');

function zorgform_render_shortcode($atts): string
{
    static $instance_count = 0;

    $atts = shortcode_atts([
        'form' => '',
        'submit' => '',
    ], $atts, 'zorgform');

    $slug = sanitize_key($atts['form']);

    if (zorgform_get_practice_key() === '') {
        return zorgform_render_notice('Stel eerst de Zorgform praktijk key in onder Instellingen > Zorgform Loader.');
    }

    if ($slug === '') {
        return zorgform_render_notice('Geef een formulier op, bijvoorbeeld [zorgform form="slug"].');
    }

    if (!zorgform_server_available()) {
        return zorgform_render_unavailable();
    }

    $form = zorgform_get_form($slug);
    if (empty($form)) {
        return zorgform_render_notice('Het formulier "' . $slug . '" kon niet worden geladen.');
    }

    $instance_count++;
    $instance_id = $slug . '-' . $instance_count;
    $submit_text = $atts['submit'] ?: zorgform_text('submit');

    wp_enqueue_style('zorgform-form', ZORGFORM_LOADER_URL . 'assets/zorgform-form.css', [], '1.5');

    ob_start();
    include ZORGFORM_LOADER_VIEWS . 'form.php';
    return ob_get_clean();
}

function zorgform_render_unavailable(): string
{
    wp_enqueue_style('zorgform-form', ZORGFORM_LOADER_URL . 'assets/zorgform-form.css', [], '1.5');

    return '<div class="zorgform-status zorgform-status--error" role="status">'
        . esc_html(zorgform_text('unavailable'))
        . '</div>';
}

function zorgform_render_notice(string $message): string
{
    return current_user_can('edit_posts')
        ? '<p class="zorgform-notice">' . esc_html($message) . '</p>'
        : '';
}
