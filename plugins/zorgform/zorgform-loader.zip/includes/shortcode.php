<?php
if ( !defined( 'ABSPATH' ) ) exit;

add_shortcode('zorgform', 'zorgform_render_shortcode');

function zorgform_render_shortcode($atts): string
{
    static $instance_count = 0;

    $atts = shortcode_atts([
        'form' => '',
        'submit' => '',
        'redirect' => '',
    ], $atts, 'zorgform');

    $slug = sanitize_key($atts['form']);

    if (zorgform_get_practice_key() === '') {
        return zorgform_render_notice('Stel eerst de Zorgform praktijk key in onder Instellingen > Zorgform Loader.');
    }

    if ($slug === '') {
        return zorgform_render_notice('Geef een formulier op, bijvoorbeeld [zorgform form="slug"].');
    }

    if (!zorgform_server_available()) {
        return zorgform_render_unavailable(zorgform_site_language());
    }

    $form = zorgform_get_form($slug);
    if (empty($form)) {
        return zorgform_render_notice('Het formulier "' . $slug . '" kon niet worden geladen.');
    }

    $instance_count++;
    $instance_id = $slug . '-' . $instance_count;
    $language = zorgform_form_language($form);
    $submit_text = $atts['submit'] ?: zorgform_text('submit', $language);
    $redirect_url = esc_url_raw($atts['redirect']);

    zorgform_enqueue_form_style();

    ob_start();
    include ZORGFORM_LOADER_VIEWS . 'form.php';
    return ob_get_clean();
}

function zorgform_render_unavailable(string $language): string
{
    zorgform_enqueue_form_style();

    return '<div class="zorgform-status zorgform-status--error" role="status">'
        . esc_html(zorgform_text('unavailable', $language))
        . '</div>';
}

function zorgform_render_notice(string $message): string
{
    return current_user_can('edit_posts')
        ? '<p class="zorgform-notice">' . esc_html($message) . '</p>'
        : '';
}

function zorgform_enqueue_form_style(): void
{
    $path = 'assets/zorgform-form.css';
    wp_enqueue_style('zorgform-form', ZORGFORM_LOADER_URL . $path, [], (string) filemtime(ZORGFORM_LOADER_PATH . $path));
}
