<?php
// Lets WordPress update this plugin from the public update.json we publish,
// so a new version installs from the plugins screen without a manual download.

if ( !defined( 'ABSPATH' ) ) exit;

define('ZORGFORM_UPDATE_BASE', 'https://WebovaBV.github.io/plugins/zorgform');
define('ZORGFORM_UPDATE_MANIFEST', ZORGFORM_UPDATE_BASE . '/update.json');

function zorgform_plugin_basename()
{
    return plugin_basename(ZORGFORM_LOADER_FILE);
}

function zorgform_plugin_slug()
{
    return dirname(zorgform_plugin_basename());
}

function zorgform_current_version()
{
    $data = get_file_data(ZORGFORM_LOADER_FILE, ['Version' => 'Version']);
    return $data['Version'];
}

function zorgform_update_manifest()
{
    $cache_key = 'zorgform_updater_manifest';
    $cached = get_transient($cache_key);
    if ($cached !== false) {
        return $cached ?: null;
    }

    $response = wp_remote_get(ZORGFORM_UPDATE_MANIFEST, ['timeout' => 15]);

    if (is_wp_error($response) || wp_remote_retrieve_response_code($response) !== 200) {
        set_transient($cache_key, [], HOUR_IN_SECONDS); // Back off on failure instead of hammering
        return null;
    }

    $manifest = json_decode(wp_remote_retrieve_body($response), true);
    if (empty($manifest['version']) || empty($manifest['download_url'])) {
        set_transient($cache_key, [], HOUR_IN_SECONDS);
        return null;
    }

    set_transient($cache_key, $manifest, 12 * HOUR_IN_SECONDS);
    return $manifest;
}

// Force a fresh lookup when the admin clicks "Check again".
add_action('load-update-core.php', function () {
    if (!empty($_GET['force-check'])) {
        delete_transient('zorgform_updater_manifest');
    }
});

add_filter('pre_set_site_transient_update_plugins', 'zorgform_check_for_update');
function zorgform_check_for_update($transient)
{
    if (empty($transient->checked)) {
        return $transient;
    }

    $manifest = zorgform_update_manifest();
    if (!$manifest) {
        return $transient;
    }

    $basename = zorgform_plugin_basename();
    $current = $transient->checked[$basename] ?? zorgform_current_version();
    $latest = ltrim($manifest['version'], 'vV');

    if (version_compare($latest, $current, '>')) {
        $transient->response[$basename] = (object) [
            'slug' => zorgform_plugin_slug(),
            'plugin' => $basename,
            'new_version' => $latest,
            'package' => $manifest['download_url'],
            'url' => $manifest['homepage'] ?? ZORGFORM_UPDATE_BASE,
            'tested' => $manifest['tested'] ?? '',
            'requires' => $manifest['requires'] ?? '',
            'requires_php' => $manifest['requires_php'] ?? '',
            'icons' => $manifest['icons'] ?? [],
            'banners' => $manifest['banners'] ?? [],
        ];
    } else {
        unset($transient->response[$basename]);
        $transient->no_update[$basename] = (object) [
            'slug' => zorgform_plugin_slug(),
            'plugin' => $basename,
            'new_version' => $current,
            'package' => '',
            'url' => $manifest['homepage'] ?? ZORGFORM_UPDATE_BASE,
        ];
    }

    return $transient;
}

add_filter('plugins_api', 'zorgform_plugin_info', 20, 3);
function zorgform_plugin_info($result, $action, $args)
{
    if ($action !== 'plugin_information' || ($args->slug ?? '') !== zorgform_plugin_slug()) {
        return $result;
    }

    $manifest = zorgform_update_manifest();
    if (!$manifest) {
        return $result;
    }

    if (!function_exists('get_plugin_data')) {
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
    }
    $data = get_plugin_data(ZORGFORM_LOADER_FILE, false, false);

    return (object) [
        'name' => $data['Name'],
        'slug' => zorgform_plugin_slug(),
        'version' => ltrim($manifest['version'], 'vV'),
        'author' => $data['Author'],
        'homepage' => $manifest['homepage'] ?? $data['PluginURI'],
        'download_link' => $manifest['download_url'],
        'requires' => $manifest['requires'] ?? ($data['RequiresWP'] ?? ''),
        'requires_php' => $manifest['requires_php'] ?? ($data['RequiresPHP'] ?? ''),
        'tested' => $manifest['tested'] ?? '',
        'last_updated' => $manifest['last_updated'] ?? '',
        'icons' => $manifest['icons'] ?? [],
        'banners' => $manifest['banners'] ?? [],
        'sections' => [
            'description' => $data['Description'],
            'changelog' => zorgform_format_changelog($manifest),
        ],
    ];
}

function zorgform_format_changelog($manifest)
{
    $changelog = trim($manifest['changelog'] ?? '');
    if ($changelog === '') {
        return 'Geen changelog beschikbaar.';
    }
    return wp_kses_post(wpautop($changelog));
}

// The zip holds the plugin files at its root; move them into a folder named
// after the installed plugin so WordPress overwrites the plugin in place.
add_filter('upgrader_source_selection', 'zorgform_rename_update_folder', 10, 4);
function zorgform_rename_update_folder($source, $remote_source, $upgrader, $hook_extra = [])
{
    if (($hook_extra['plugin'] ?? '') !== zorgform_plugin_basename()) {
        return $source;
    }

    global $wp_filesystem;
    $slug = zorgform_plugin_slug();
    $desired = trailingslashit($remote_source) . $slug;

    if (untrailingslashit($source) === $desired) {
        return trailingslashit($desired);
    }

    // Files extracted straight into the working dir: move them into a subfolder.
    if (untrailingslashit($source) === untrailingslashit($remote_source)) {
        $wp_filesystem->mkdir($desired);
        foreach (array_keys($wp_filesystem->dirlist($source)) as $name) {
            if ($name === $slug) {
                continue;
            }
            $wp_filesystem->move(trailingslashit($source) . $name, trailingslashit($desired) . $name, true);
        }
        return trailingslashit($desired);
    }

    // Extracted into a wrapper folder: rename it to the plugin slug.
    if ($wp_filesystem->move(untrailingslashit($source), $desired, true)) {
        return trailingslashit($desired);
    }

    return $source;
}
