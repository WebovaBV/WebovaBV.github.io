<?php
add_action('admin_menu', function () {
    add_options_page('Zorgform Loader Settings','Zorgform Loader','manage_options','zorgform-loader','zorgform_loader_settings_page');
});


add_action('admin_init', function () {
    register_setting('zorgform_loader_options', 'zorgform_loader_practice_key', [
        'sanitize_callback' => 'sanitize_text_field',
    ]);
    register_setting('zorgform_loader_options', ZORGFORM_TEXTS_OPTION, [
        'type' => 'array',
        'sanitize_callback' => 'zorgform_sanitize_texts',
    ]);
});

add_action('update_option_zorgform_loader_practice_key', 'zorgform_clear_cache');

add_action('admin_post_zorgform_clear_cache', function () {
    if (!current_user_can('manage_options')) {
        wp_die('Geen toegang.');
    }
    check_admin_referer('zorgform_clear_cache');

    zorgform_clear_cache();
    wp_safe_redirect(add_query_arg(['page' => 'zorgform-loader', 'zorgform_cache' => 'cleared'], admin_url('options-general.php')));
    exit;
});

function zorgform_loader_settings_page()
{
?>
    <div class="wrap">
        <h1>Instellingen Zorgform Loader</h1>
        <?php if (($_GET['zorgform_cache'] ?? '') === 'cleared') : ?>
            <div class="notice notice-success is-dismissible"><p>De formulier-cache is geleegd.</p></div>
        <?php endif; ?>
        <form method="post" action="options.php">
            <?php
                settings_fields('zorgform_loader_options');
                do_settings_sections('zorgform_loader_options');
                $practice_key = esc_attr(get_option('zorgform_loader_practice_key', ''));
            ?>
            <table class="form-table">
                <tr valign="top">
                    <th scope="row">Zorgform praktijk Key</th>
                    <td>
                        <input type="text" name="zorgform_loader_practice_key" value="<?php echo $practice_key; ?>" size="40" />
                        <p class="description">Voer hier uw Zorgform praktijksleutel in.</p>
                    </td>
                </tr>
            </table>
            <?php zorgform_render_text_settings(); ?>
            <?php submit_button(); ?>
        </form>

        <?php zorgform_render_shortcode_list(); ?>

        <h2>Formulier-cache</h2>
        <p>Formulieren worden 30 minuten bewaard. Leeg de cache om wijzigingen in Zorgform direct te zien.</p>
        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
            <input type="hidden" name="action" value="zorgform_clear_cache">
            <?php wp_nonce_field('zorgform_clear_cache'); ?>
            <?php submit_button('Cache legen', 'secondary', 'submit', false); ?>
        </form>
    </div>
<?php
}

function zorgform_render_text_settings()
{
?>
    <h2>Teksten</h2>
    <p>Laat een veld leeg om de standaardtekst te gebruiken. De taal van het formulier in Zorgform bepaalt welke tekst wordt getoond, onbekende talen krijgen de Engelse tekst.</p>
    <table class="form-table">
        <?php foreach (zorgform_text_definitions() as $key => $text) : ?>
            <tr valign="top">
                <th scope="row"><?php echo esc_html($text['label']); ?></th>
                <td>
                    <?php foreach (ZORGFORM_LANGUAGES as $language => $language_name) : ?>
                        <?php $input_id = 'zorgform-text-' . $language . '-' . $key; ?>
                        <p>
                            <label for="<?php echo esc_attr($input_id); ?>"><?php echo esc_html($language_name); ?></label><br>
                            <input type="text" class="large-text"
                                id="<?php echo esc_attr($input_id); ?>"
                                name="<?php echo esc_attr(ZORGFORM_TEXTS_OPTION . '[' . $language . '][' . $key . ']'); ?>"
                                value="<?php echo esc_attr(zorgform_saved_text($key, $language)); ?>"
                                placeholder="<?php echo esc_attr(zorgform_default_text($key, $language)); ?>" />
                        </p>
                    <?php endforeach; ?>
                    <?php if (!empty($text['description'])) : ?>
                        <p class="description"><?php echo esc_html($text['description']); ?></p>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; ?>
    </table>
<?php
}

function zorgform_render_shortcode_list()
{
    if (zorgform_get_practice_key() === '') {
        return;
    }

    $forms = zorgform_get_forms();
?>
    <h2>Formulieren</h2>
    <?php if (empty($forms)) : ?>
        <p>Er konden geen formulieren worden opgehaald. Controleer de praktijk key.</p>
    <?php else : ?>
        <p>Plaats een formulier op een pagina met de shortcode. Je kunt de shortcode uitbreiden met deze opties:</p>
        <ul style="list-style: disc; padding-left: 20px;">
            <li><code>submit="..."</code> past de tekst van de verzendknop aan.</li>
            <li><code>redirect="..."</code> stuurt de bezoeker na succesvol versturen naar een andere pagina, bijvoorbeeld <code>redirect="https://example.com/bedankt"</code>. Bij een fout blijft de bezoeker op het formulier en ziet de melding.</li>
        </ul>
        <table class="widefat striped" style="max-width: 800px;">
            <thead><tr><th>Formulier</th><th>Shortcode</th></tr></thead>
            <tbody>
                <?php foreach ($forms as $slug => $name) : ?>
                    <tr>
                        <td><?php echo esc_html($name); ?></td>
                        <td><code>[zorgform form="<?php echo esc_attr($slug); ?>"]</code></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
<?php
}
