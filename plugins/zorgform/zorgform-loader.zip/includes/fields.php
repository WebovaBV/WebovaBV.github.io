<?php
if ( !defined( 'ABSPATH' ) ) exit;

const ZORGFORM_YES_NO = ['Ja', 'Nee'];

function zorgform_field_is_yes_no(array $field): bool
{
    return ($field['type'] ?? '') === 'select' && empty($field['options']);
}

function zorgform_field_options(array $field): array
{
    return zorgform_field_is_yes_no($field) ? ZORGFORM_YES_NO : array_values((array) ($field['options'] ?? []));
}

function zorgform_field_input_type(array $field): string
{
    if (($field['type'] ?? '') === 'date') {
        return 'date';
    }
    return ($field['id'] ?? '') === 'email' ? 'email' : 'text';
}
