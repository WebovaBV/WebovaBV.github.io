<?php
if ( !defined( 'ABSPATH' ) ) exit;

const ZORGFORM_YES_NO = ['Ja', 'Nee'];

const ZORGFORM_CONSENT_KEYS = ['consent_legal', 'consent_privacy'];

const ZORGFORM_DISPLAY_TYPES = ['pagetitle', 'subheader', 'textbox'];

function zorgform_field_is_display_only(array $field): bool
{
    return in_array($field['type'] ?? '', ZORGFORM_DISPLAY_TYPES, true);
}

function zorgform_field_is_yes_no(array $field): bool
{
    return ($field['type'] ?? '') === 'select' && empty($field['options']);
}

function zorgform_yes_no_label(string $option, string $language): string
{
    return zorgform_text($option === ZORGFORM_YES_NO[0] ? 'yes' : 'no', $language);
}

function zorgform_field_options(array $field): array
{
    return zorgform_field_is_yes_no($field) ? ZORGFORM_YES_NO : array_values((array) ($field['options'] ?? []));
}

function zorgform_field_input_type(array $field): string
{
    if (($field['type'] ?? '') === 'date') {
        return 'date';
    }
    return ($field['id'] ?? '') === 'email' ? 'email' : 'text';
}
