<?php
    add_action('wp_footer', function () {
        $practice_key = esc_js(get_option('zorgform_loader_practice_key', ''));
        if (!$practice_key) {
            return;
        }
?>
    <script src="https://veilig.zorgform.nl/plugin/plugin.js"></script>
    <script>
        const zorgform = new zorgformCli('<?php echo $practice_key; ?>');
    </script>
<?php
});
