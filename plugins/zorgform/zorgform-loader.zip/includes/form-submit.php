<?php
if ( !defined( 'ABSPATH' ) ) exit;

add_action('admin_post_zorgform_form_submit', 'zorgform_handle_form_submit');
add_action('admin_post_nopriv_zorgform_form_submit', 'zorgform_handle_form_submit');

function zorgform_handle_form_submit(): void
{
    $slug = sanitize_key($_POST['form_slug'] ?? '');
    $instance_id = sanitize_key($_POST['instance_id'] ?? '');

    if (!wp_verify_nonce($_POST['zorgform_nonce'] ?? '', 'zorgform_form_submit_' . $slug)) {
        zorgform_redirect_with_status($instance_id, false, zorgform_text('session_expired'));
    }

    $form = zorgform_get_form($slug);
    if (empty($form)) {
        zorgform_redirect_with_status($instance_id, false, zorgform_text('form_not_loaded'));
    }

    $input = (array) wp_unslash($_POST['zorgform'] ?? []);
    $answers = zorgform_collect_answers($form['fields'], $input);

    if (is_wp_error($answers)) {
        zorgform_redirect_with_status($instance_id, false, $answers->get_error_message());
    }

    $result = zorgform_submit_form($slug, $answers);
    zorgform_redirect_with_status($instance_id, $result['success'], $result['message']);
}

/**
 * @return array<string, string>|WP_Error
 */
function zorgform_collect_answers(array $fields, array $input)
{
    $answers = [];

    foreach ($fields as $field) {
        if (empty($field['id'])) {
            continue;
        }

        $value = zorgform_sanitize_field_value($field, $input[$field['id']] ?? '');

        if ($value === '' && !empty($field['required'])) {
            return new WP_Error('zorgform_required', zorgform_text('required', ['{veld}' => $field['label'] ?? $field['id']]));
        }

        $answers[$field['id']] = $value;
    }

    return $answers;
}

function zorgform_sanitize_field_value(array $field, $raw): string
{
    $value = is_scalar($raw) ? sanitize_text_field((string) $raw) : '';

    switch ($field['type'] ?? 'text') {
        case 'select':
            return in_array($value, zorgform_field_options($field), true) ? $value : '';
        case 'date':
            $date = DateTime::createFromFormat('!Y-m-d', $value);
            return $date ? $date->format('d-m-Y') : '';
        default:
            return $value;
    }
}

function zorgform_redirect_with_status(string $instance_id, bool $success, string $message): void
{
    $referer = wp_get_referer() ?: home_url('/');
    $referer = remove_query_arg(['zorgform_status', 'zorgform_instance', 'zorgform_message'], $referer);

    $url = add_query_arg([
        'zorgform_status' => $success ? 'success' : 'error',
        'zorgform_instance' => $instance_id,
        'zorgform_message' => rawurlencode($message),
    ], $referer);

    wp_safe_redirect($url . '#zorgform-' . $instance_id);
    exit;
}
