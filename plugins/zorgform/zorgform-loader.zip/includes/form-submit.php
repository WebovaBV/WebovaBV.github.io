<?php
if ( !defined( 'ABSPATH' ) ) exit;

add_action('admin_post_zorgform_form_submit', 'zorgform_handle_form_submit');
add_action('admin_post_nopriv_zorgform_form_submit', 'zorgform_handle_form_submit');

const ZORGFORM_HONEYPOT_FIELD = 'zorgform_website';

function zorgform_handle_form_submit(): void
{
    $slug = sanitize_key($_POST['form_slug'] ?? '');
    $instance_id = sanitize_key($_POST['instance_id'] ?? '');
    $redirect_url = esc_url_raw(wp_unslash($_POST['redirect_url'] ?? ''));

    if (zorgform_honeypot_filled()) {
        zorgform_redirect_with_status($instance_id, true, zorgform_text('success', zorgform_site_language()));
    }

    if (!wp_verify_nonce($_POST['zorgform_nonce'] ?? '', zorgform_nonce_action($slug, $redirect_url))) {
        zorgform_redirect_with_status($instance_id, false, zorgform_text('session_expired', zorgform_site_language()));
    }

    $form = zorgform_get_form($slug);
    $language = zorgform_form_language($form);

    if (empty($form)) {
        zorgform_redirect_with_status($instance_id, false, zorgform_text('form_not_loaded', $language));
    }

    if (!zorgform_consent_given()) {
        zorgform_redirect_with_status($instance_id, false, zorgform_text('consent_required', $language));
    }

    $input = (array) wp_unslash($_POST['zorgform'] ?? []);
    $answers = zorgform_collect_answers($form['fields'], $input, $language);

    if (is_wp_error($answers)) {
        zorgform_redirect_with_status($instance_id, false, $answers->get_error_message());
    }

    $result = zorgform_submit_form($slug, $answers, $language);

    if ($result['success'] && $redirect_url !== '') {
        wp_redirect($redirect_url);
        exit;
    }

    zorgform_redirect_with_status($instance_id, $result['success'], $result['message']);
}

// The redirect URL is part of the nonce action so it cannot be changed in the browser.
function zorgform_nonce_action(string $slug, string $redirect_url): string
{
    return 'zorgform_form_submit_' . $slug . '|' . $redirect_url;
}

function zorgform_honeypot_filled(): bool
{
    $value = $_POST[ZORGFORM_HONEYPOT_FIELD] ?? '';

    return is_array($value) || trim((string) $value) !== '';
}

function zorgform_consent_given(): bool
{
    $consent = (array) ($_POST['zorgform_consent'] ?? []);

    foreach (ZORGFORM_CONSENT_KEYS as $key) {
        if (($consent[$key] ?? '') !== '1') {
            return false;
        }
    }

    return true;
}

/**
 * @return array<string, string>|WP_Error
 */
function zorgform_collect_answers(array $fields, array $input, string $language)
{
    $answers = [];

    foreach ($fields as $field) {
        if (empty($field['id']) || zorgform_field_is_display_only($field)) {
            continue;
        }

        $value = zorgform_sanitize_field_value($field, $input[$field['id']] ?? '');

        if ($value === '' && !empty($field['required'])) {
            return new WP_Error('zorgform_required', zorgform_text('required', $language, ['{veld}' => $field['label'] ?? $field['id']]));
        }

        $answers[$field['id']] = $value;
    }

    return $answers;
}

function zorgform_sanitize_field_value(array $field, $raw): string
{
    if (!is_scalar($raw)) {
        return '';
    }

    $type = $field['type'] ?? 'text';
    if ($type === 'textarea') {
        return sanitize_textarea_field((string) $raw);
    }

    $value = sanitize_text_field((string) $raw);

    switch ($type) {
        case 'select':
            return in_array($value, zorgform_field_options($field), true) ? $value : '';
        case 'date':
            $date = DateTime::createFromFormat('!Y-m-d', $value);
            return $date ? $date->format('d-m-Y') : '';
        default:
            return $value;
    }
}

function zorgform_redirect_with_status(string $instance_id, bool $success, string $message): void
{
    $referer = wp_get_referer() ?: home_url('/');
    $referer = remove_query_arg(['zorgform_status', 'zorgform_instance', 'zorgform_message'], $referer);

    $url = add_query_arg([
        'zorgform_status' => $success ? 'success' : 'error',
        'zorgform_instance' => $instance_id,
        'zorgform_message' => rawurlencode($message),
    ], $referer);

    wp_safe_redirect($url . '#zorgform-' . $instance_id);
    exit;
}
