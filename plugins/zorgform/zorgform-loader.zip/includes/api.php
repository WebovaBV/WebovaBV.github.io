<?php
if ( !defined( 'ABSPATH' ) ) exit;

const ZORGFORM_CACHE_TTL = 1800;
const ZORGFORM_STATUS_TTL = 60;

function zorgform_get_practice_key(): string
{
    return (string) get_option('zorgform_loader_practice_key', '');
}

function zorgform_form_url(string $slug = ''): string
{
    $url = trailingslashit(ZORGFORM_API_URL) . rawurlencode(zorgform_get_practice_key()) . '/form';
    return $slug === '' ? $url : $url . '/' . rawurlencode($slug);
}

function zorgform_decode_response($response): array
{
    if (is_wp_error($response)) {
        return [];
    }

    $data = json_decode(wp_remote_retrieve_body($response), true);
    return is_array($data) ? $data : [];
}

function zorgform_cached_get(string $cache_key, string $url): array
{
    $cached = get_transient($cache_key);
    if (is_array($cached) && !empty($cached)) {
        return $cached;
    }

    $response = wp_remote_get($url, ['timeout' => 15]);
    $data = zorgform_decode_response($response);

    if (wp_remote_retrieve_response_code($response) !== 200 || empty($data)) {
        return [];
    }

    set_transient($cache_key, $data, ZORGFORM_CACHE_TTL);
    return $data;
}

/**
 * @return array<string, string> slug => name
 */
function zorgform_get_forms(): array
{
    $practice_key = zorgform_get_practice_key();
    if ($practice_key === '') {
        return [];
    }

    $data = zorgform_cached_get('zorgform_forms_' . md5($practice_key), zorgform_form_url());

    $forms = [];
    foreach ((array) ($data['forms'] ?? []) as $form) {
        if (!empty($form['slug'])) {
            $forms[$form['slug']] = $form['name'] ?? $form['slug'];
        }
    }
    asort($forms, SORT_NATURAL | SORT_FLAG_CASE);

    return $forms;
}

function zorgform_get_form(string $slug): array
{
    $practice_key = zorgform_get_practice_key();
    if ($practice_key === '' || $slug === '') {
        return [];
    }

    $data = zorgform_cached_get('zorgform_form_' . md5($practice_key . '|' . $slug), zorgform_form_url($slug));

    return isset($data['fields']) && is_array($data['fields']) ? $data : [];
}

/**
 * @return array{success: bool, message: string}
 */
function zorgform_submit_form(string $slug, array $answers): array
{
    $response = wp_remote_post(zorgform_form_url($slug), [
        'timeout' => 15,
        'headers' => [
            'Content-Type' => 'application/json',
            'Accept' => 'application/json',
        ],
        'body' => wp_json_encode($answers),
    ]);

    $status = wp_remote_retrieve_response_code($response);
    $data = zorgform_decode_response($response);
    $success = $status >= 200 && $status < 300;

    $message = $success
        ? zorgform_text('success')
        : ($data['message'] ?? zorgform_text('error'));

    return ['success' => $success, 'message' => (string) $message];
}

function zorgform_server_available(): bool
{
    $cached = get_transient('zorgform_server_status');
    if ($cached !== false) {
        return $cached === 'up';
    }

    $response = wp_remote_head(zorgform_form_url(), ['timeout' => 5]);
    $available = !is_wp_error($response) && wp_remote_retrieve_response_code($response) < 500;

    set_transient('zorgform_server_status', $available ? 'up' : 'down', ZORGFORM_STATUS_TTL);
    return $available;
}

function zorgform_clear_cache(): void
{
    global $wpdb;

    $wpdb->query(
        "DELETE FROM {$wpdb->options}
         WHERE option_name LIKE '\_transient\_zorgform\_%'
            OR option_name LIKE '\_transient\_timeout\_zorgform\_%'"
    );
}
