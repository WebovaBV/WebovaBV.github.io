<?php
if ( !defined( 'ABSPATH' ) ) exit;

const ZORGFORM_TEXTS_OPTION = 'zorgform_loader_texts';

/**
 * @return array<string, array{label: string, default: string, description?: string}>
 */
function zorgform_text_definitions(): array
{
    return [
        'submit' => [
            'label' => 'Verzendknop',
            'default' => 'Versturen',
            'description' => 'Per formulier te overschrijven met submit="..." in de shortcode.',
        ],
        'success' => [
            'label' => 'Formulier verzonden',
            'default' => 'Bedankt, uw formulier is verzonden.',
        ],
        'error' => [
            'label' => 'Verzenden mislukt',
            'default' => 'Er is iets misgegaan bij het verzenden. Probeer het later opnieuw.',
            'description' => 'Wordt alleen getoond als Zorgform zelf geen foutmelding teruggeeft.',
        ],
        'required' => [
            'label' => 'Verplicht veld leeg',
            'default' => 'Vul het veld "{veld}" in.',
            'description' => '{veld} wordt vervangen door de naam van het veld.',
        ],
        'session_expired' => [
            'label' => 'Sessie verlopen',
            'default' => 'De sessie is verlopen. Vernieuw de pagina en probeer het opnieuw.',
        ],
        'form_not_loaded' => [
            'label' => 'Formulier niet geladen',
            'default' => 'Het formulier kon niet worden geladen.',
        ],
        'unavailable' => [
            'label' => 'Formulier niet beschikbaar',
            'default' => 'Het formulier is op dit moment niet beschikbaar. Probeer het later opnieuw.',
        ],
    ];
}

function zorgform_text(string $key, array $replacements = []): string
{
    $saved = (array) get_option(ZORGFORM_TEXTS_OPTION, []);
    $text = trim((string) ($saved[$key] ?? ''));

    if ($text === '') {
        $text = zorgform_text_definitions()[$key]['default'] ?? '';
    }

    return strtr($text, $replacements);
}

function zorgform_sanitize_texts($input): array
{
    $texts = [];

    foreach (array_keys(zorgform_text_definitions()) as $key) {
        $texts[$key] = sanitize_text_field($input[$key] ?? '');
    }

    return $texts;
}
