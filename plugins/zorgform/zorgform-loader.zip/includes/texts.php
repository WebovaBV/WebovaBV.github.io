<?php
if ( !defined( 'ABSPATH' ) ) exit;

const ZORGFORM_TEXTS_OPTION = 'zorgform_loader_texts';

const ZORGFORM_LANGUAGES = [
    'nl' => 'Nederlands',
    'en' => 'English',
];

const ZORGFORM_FALLBACK_LANGUAGE = 'en';

/**
 * @return array<string, array{label: string, default: array<string, string>, description?: string}>
 */
function zorgform_text_definitions(): array
{
    return [
        'submit' => [
            'label' => 'Verzendknop',
            'default' => [
                'nl' => 'Versturen',
                'en' => 'Submit',
            ],
            'description' => 'Per formulier te overschrijven met submit="..." in de shortcode.',
        ],
        'success' => [
            'label' => 'Formulier verzonden',
            'default' => [
                'nl' => 'Bedankt, uw formulier is verzonden.',
                'en' => 'Thank you, your form has been submitted.',
            ],
        ],
        'error' => [
            'label' => 'Verzenden mislukt',
            'default' => [
                'nl' => 'Er is iets misgegaan bij het verzenden. Probeer het later opnieuw.',
                'en' => 'Something went wrong while submitting. Please try again later.',
            ],
            'description' => 'Wordt alleen getoond als Zorgform zelf geen foutmelding teruggeeft.',
        ],
        'required' => [
            'label' => 'Verplicht veld leeg',
            'default' => [
                'nl' => 'Vul het veld "{veld}" in.',
                'en' => 'Please fill in the field "{veld}".',
            ],
            'description' => '{veld} wordt vervangen door de naam van het veld.',
        ],
        'choose' => [
            'label' => 'Keuzelijst placeholder',
            'default' => [
                'nl' => 'Maak een keuze',
                'en' => 'Make a choice',
            ],
            'description' => 'Wordt alleen getoond als het veld in Zorgform geen placeholder heeft.',
        ],
        'yes' => [
            'label' => 'Ja',
            'default' => [
                'nl' => 'Ja',
                'en' => 'Yes',
            ],
        ],
        'no' => [
            'label' => 'Nee',
            'default' => [
                'nl' => 'Nee',
                'en' => 'No',
            ],
        ],
        'consent_legal' => [
            'label' => 'Akkoord juridische status',
            'default' => [
                'nl' => 'Ik begrijp dat het digitaal invullen en bevestigen van dit formulier dezelfde juridische status heeft als een schriftelijke verklaring of ondertekening. Ik verklaar dit formulier naar waarheid te hebben ingevuld',
                'en' => 'I understand that completing and confirming this form digitally has the same legal status as a written statement or signature. I declare that I have completed this form truthfully',
            ],
        ],
        'consent_privacy' => [
            'label' => 'Akkoord verwerking gegevens',
            'default' => [
                'nl' => 'Ik ga akkoord met de verwerking van mijn gegevens zoals beschreven in de Disclaimer/Voorwaarden',
                'en' => 'I agree to the processing of my data as described in the Disclaimer/Terms',
            ],
        ],
        'consent_required' => [
            'label' => 'Akkoord ontbreekt',
            'default' => [
                'nl' => 'Vink alle akkoordverklaringen aan om het formulier te versturen.',
                'en' => 'Please check all declarations of consent to submit the form.',
            ],
        ],
        'session_expired' => [
            'label' => 'Sessie verlopen',
            'default' => [
                'nl' => 'De sessie is verlopen. Vernieuw de pagina en probeer het opnieuw.',
                'en' => 'Your session has expired. Please refresh the page and try again.',
            ],
        ],
        'form_not_loaded' => [
            'label' => 'Formulier niet geladen',
            'default' => [
                'nl' => 'Het formulier kon niet worden geladen.',
                'en' => 'The form could not be loaded.',
            ],
        ],
        'unavailable' => [
            'label' => 'Formulier niet beschikbaar',
            'default' => [
                'nl' => 'Het formulier is op dit moment niet beschikbaar. Probeer het later opnieuw.',
                'en' => 'The form is currently unavailable. Please try again later.',
            ],
        ],
    ];
}

function zorgform_resolve_language(string $language): string
{
    $code = strtolower(substr(trim($language), 0, 2));

    return isset(ZORGFORM_LANGUAGES[$code]) ? $code : ZORGFORM_FALLBACK_LANGUAGE;
}

function zorgform_form_language(array $form): string
{
    return empty($form)
        ? zorgform_site_language()
        : zorgform_resolve_language((string) ($form['language'] ?? ''));
}

function zorgform_site_language(): string
{
    return zorgform_resolve_language(get_locale());
}

function zorgform_saved_text(string $key, string $language): string
{
    $saved = (array) get_option(ZORGFORM_TEXTS_OPTION, []);
    $value = $saved[$language][$key] ?? null;

    $is_legacy_dutch_value = $value === null && $language === 'nl' && is_string($saved[$key] ?? null);
    if ($is_legacy_dutch_value) {
        $value = $saved[$key];
    }

    return trim((string) $value);
}

function zorgform_default_text(string $key, string $language): string
{
    $defaults = zorgform_text_definitions()[$key]['default'] ?? [];

    return $defaults[$language] ?? $defaults[ZORGFORM_FALLBACK_LANGUAGE] ?? '';
}

function zorgform_text(string $key, string $language, array $replacements = []): string
{
    $text = zorgform_saved_text($key, $language);

    if ($text === '') {
        $text = zorgform_default_text($key, $language);
    }

    return strtr($text, $replacements);
}

function zorgform_sanitize_texts($input): array
{
    $input = (array) $input;
    $texts = [];

    foreach (array_keys(ZORGFORM_LANGUAGES) as $language) {
        foreach (array_keys(zorgform_text_definitions()) as $key) {
            $texts[$language][$key] = sanitize_text_field($input[$language][$key] ?? '');
        }
    }

    return $texts;
}
