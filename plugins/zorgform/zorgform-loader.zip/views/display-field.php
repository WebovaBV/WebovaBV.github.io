<?php
if ( !defined( 'ABSPATH' ) ) exit;

$display_type = $field['type'] ?? '';
$display_label = $field['label'] ?? '';
$display_body = array_values((array) ($field['body'] ?? []));
?>
<?php if ($display_type === 'pagetitle') : ?>
    <b class="zorgform-page-title elementor-column elementor-col-100"><?php echo esc_html($display_label); ?></b>

<?php elseif ($display_type === 'subheader') : ?>
    <b class="zorgform-subheader elementor-column elementor-col-100"><?php echo esc_html($display_label); ?></b>

<?php elseif ($display_type === 'textbox') : ?>
    <div class="zorgform-textbox elementor-field-group elementor-column elementor-col-100">
        <?php if ($display_label !== '') : ?>
            <span class="elementor-field-label"><?php echo esc_html($display_label); ?></span>
        <?php endif; ?>

        <?php if (!empty($field['list'])) : ?>
            <ul>
                <?php foreach ($display_body as $line) : ?>
                    <li><?php echo esc_html($line); ?></li>
                <?php endforeach; ?>
            </ul>
        <?php else : ?>
            <?php foreach ($display_body as $line) : ?>
                <p><?php echo esc_html($line); ?></p>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
<?php endif; ?>
