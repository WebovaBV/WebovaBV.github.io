<?php
if ( !defined( 'ABSPATH' ) ) exit;

$zorgform_status = sanitize_key($_GET['zorgform_status'] ?? '');
$zorgform_show_status = $zorgform_status !== '' && ($_GET['zorgform_instance'] ?? '') === $instance_id;
?>
<div class="zorgform-form-wrapper" id="zorgform-<?php echo esc_attr($instance_id); ?>">
    <?php if ($zorgform_show_status) : ?>
        <div class="zorgform-status zorgform-status--<?php echo esc_attr($zorgform_status); ?>" role="status">
            <?php echo esc_html(sanitize_text_field(wp_unslash($_GET['zorgform_message'] ?? ''))); ?>
        </div>
    <?php endif; ?>

    <form class="elementor-form zorgform-form" method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
        <input type="hidden" name="action" value="zorgform_form_submit">
        <input type="hidden" name="form_slug" value="<?php echo esc_attr($slug); ?>">
        <input type="hidden" name="instance_id" value="<?php echo esc_attr($instance_id); ?>">
        <?php wp_nonce_field('zorgform_form_submit_' . $slug, 'zorgform_nonce'); ?>
        <style>
        .zorgform-<?php echo esc_attr($instance_id); ?> {
            position: absolute;
            left: -9999px;
            width: 1px;
            height: 1px;
            overflow: hidden;
        }
        </style>
        <div class="zorgform-<?php echo esc_attr($instance_id); ?>">
            <label for="zorgform-<?php echo esc_attr($instance_id); ?>-website">Website</label>
            <input type="text" id="zorgform-<?php echo esc_attr($instance_id); ?>-website" name="<?php echo esc_attr(ZORGFORM_HONEYPOT_FIELD); ?>" value="" tabindex="-1" autocomplete="off">
        </div>
        <div class="elementor-form-fields-wrapper elementor-labels-above zorgform-fields-wrapper">
            <?php foreach ($form['fields'] as $field) : ?>
                <?php if (!empty($field['id'])) include ZORGFORM_LOADER_VIEWS . 'field.php'; ?>
            <?php endforeach; ?>
            <div class="elementor-field-group elementor-column elementor-field-type-submit elementor-col-100">
                <button type="submit" class="elementor-button elementor-size-sm">
                    <span class="elementor-button-text"><?php echo esc_html($submit_text); ?></span>
                </button>
            </div>
        </div>
    </form>
</div>
