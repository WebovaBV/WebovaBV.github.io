<?php
if ( !defined( 'ABSPATH' ) ) exit;

$field_name = 'zorgform[' . $field['id'] . ']';
$field_id = 'zorgform-' . $instance_id . '-' . $field['id'];
$field_required = !empty($field['required']);
$required_attr = $field_required ? ' required' : '';
$placeholder = $field['placeholder'] ?? '';
?>
<div class="zorgform-field elementor-field-group elementor-column elementor-col-100<?php echo $field_required ? ' elementor-field-required elementor-mark-required' : ''; ?>">
    <label class="elementor-field-label"<?php echo zorgform_field_is_yes_no($field) ? '' : ' for="' . esc_attr($field_id) . '"'; ?>>
        <?php echo esc_html($field['label'] ?? $field['id']); ?>
    </label>

    <?php if (zorgform_field_is_yes_no($field)) : ?>
        <div class="elementor-field-subgroup elementor-subgroup-inline" role="radiogroup">
            <?php foreach (ZORGFORM_YES_NO as $index => $option) : ?>
                <span class="elementor-field-option">
                    <input type="radio" id="<?php echo esc_attr($field_id . '-' . $index); ?>" name="<?php echo esc_attr($field_name); ?>" value="<?php echo esc_attr($option); ?>"<?php echo $required_attr; ?>>
                    <label for="<?php echo esc_attr($field_id . '-' . $index); ?>"><?php echo esc_html($option); ?></label>
                </span>
            <?php endforeach; ?>
        </div>

    <?php elseif (($field['type'] ?? '') === 'select') : ?>
        <?php $standard = $field['standard'] ?? ''; ?>
        <div class="elementor-field elementor-select-wrapper">
            <select id="<?php echo esc_attr($field_id); ?>" name="<?php echo esc_attr($field_name); ?>" class="elementor-field-textual elementor-size-sm"<?php echo $required_attr; ?>>
                <?php if ($standard === '') : ?>
                    <option value="" disabled selected><?php echo esc_html($placeholder ?: 'Maak een keuze'); ?></option>
                <?php endif; ?>
                <?php foreach (zorgform_field_options($field) as $option) : ?>
                    <option value="<?php echo esc_attr($option); ?>"<?php selected($option, $standard); ?>><?php echo esc_html($option); ?></option>
                <?php endforeach; ?>
            </select>
        </div>

    <?php else : ?>
        <input id="<?php echo esc_attr($field_id); ?>" name="<?php echo esc_attr($field_name); ?>" type="<?php echo esc_attr(zorgform_field_input_type($field)); ?>" class="elementor-field elementor-size-sm elementor-field-textual" placeholder="<?php echo esc_attr($placeholder); ?>"<?php echo $required_attr; ?>>
    <?php endif; ?>
</div>
