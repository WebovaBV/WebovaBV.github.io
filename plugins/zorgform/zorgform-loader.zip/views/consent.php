<?php
if ( !defined( 'ABSPATH' ) ) exit;
?>
<div class="zorgform-consent elementor-field-group elementor-column elementor-col-100 elementor-field-required">
    <?php foreach (ZORGFORM_CONSENT_KEYS as $consent_key) : ?>
        <?php $consent_id = 'zorgform-' . $instance_id . '-' . $consent_key; ?>
        <span class="zorgform-consent-option elementor-field-option">
            <input type="checkbox" id="<?php echo esc_attr($consent_id); ?>" name="zorgform_consent[<?php echo esc_attr($consent_key); ?>]" value="1" required>
            <label for="<?php echo esc_attr($consent_id); ?>"><?php echo esc_html(zorgform_text($consent_key, $language)); ?></label>
        </span>
    <?php endforeach; ?>
</div>
