<?php
/*
Plugin Name: Zorgform loader
Description: Zorgform loader is a WordPress plugin that allows you to load Zorgform forms into your WordPress site. It provides a simple way to integrate Zorgform forms with your WordPress content, enabling you to create and manage forms easily.
Version: 1.5.2
Author: Zorgform
Requires PHP: 8.1
*/

// Prevent direct access
if ( !defined( 'ABSPATH' ) ) exit;

define('ZORGFORM_LOADER_FILE', __FILE__);
define('ZORGFORM_LOADER_PATH', plugin_dir_path(__FILE__));
define('ZORGFORM_LOADER_URL', plugin_dir_url(__FILE__));
define('ZORGFORM_LOADER_VIEWS', ZORGFORM_LOADER_PATH . 'views/');
define('ZORGFORM_API_URL', WP_DEBUG ? 'http://host.docker.internal:8000/api/v1/' : 'https://veilig.zorgform.nl/api/v1/');

// Includes
require_once ZORGFORM_LOADER_PATH . 'includes/texts.php';
require_once ZORGFORM_LOADER_PATH . 'includes/api.php';
require_once ZORGFORM_LOADER_PATH . 'includes/fields.php';
require_once ZORGFORM_LOADER_PATH . 'includes/admin-settings.php';
require_once ZORGFORM_LOADER_PATH . 'includes/frontend-inject.php';
require_once ZORGFORM_LOADER_PATH . 'includes/form-submit.php';
require_once ZORGFORM_LOADER_PATH . 'includes/shortcode.php';
require_once ZORGFORM_LOADER_PATH . 'includes/plugin-uninstall.php';
require_once ZORGFORM_LOADER_PATH . 'includes/plugin-updater.php';
