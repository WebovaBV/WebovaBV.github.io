<?php
require_once AIVORY_INCLUDES_PATH . 'core.php';
$tenantId = getTenantId();
$appointmentTypes = getAppointmentTypes();
$ajaxUrl = admin_url('admin-ajax.php');
$nonce = wp_create_nonce('aivory_booking');
$uid = uniqid('aivory_booking_');
?>
<div id="<?php echo esc_attr($uid); ?>" class="aivory-booking">
    <div class="aivory-booking-message" style="display:none;margin-bottom:1rem;padding:12px;border-radius:6px;"></div>

    <!-- Step 1: identify -->
    <div class="aivory-booking-step" data-step="1">
        <div class="elementor-field-type-select elementor-field-group elementor-column elementor-col-100 elementor-field-required elementor-mark-required">
            <label class="elementor-field-label" style="padding-top:10px;padding-bottom:3px;">Type afspraak</label>
            <select name="appointmentTypeId" class="aivory-appointment-type elementor-field elementor-size-md elementor-field-textual" required="required">
                <option value="" disabled selected>Kies een type afspraak</option>
                <?php foreach ($appointmentTypes as $type) { ?>
                    <option value="<?php echo esc_attr($type['id']); ?>"><?php echo esc_html($type['name']); ?></option>
                <?php } ?>
            </select>
        </div>
        <div class="elementor-field-type-text elementor-field-group elementor-column elementor-col-100 elementor-field-required elementor-mark-required">
            <label class="elementor-field-label" style="padding-top:10px;padding-bottom:3px;">E-mail</label>
            <input type="email" name="email" class="aivory-email elementor-field elementor-size-md elementor-field-textual" required="required">
        </div>
        <div class="elementor-field-type-text elementor-field-group elementor-column elementor-col-100 elementor-field-required elementor-mark-required">
            <label class="elementor-field-label" style="padding-top:10px;padding-bottom:3px;">Geboortedatum</label>
            <input type="date" name="dateOfBirth" class="aivory-dob elementor-field elementor-size-md elementor-field-textual" required="required">
        </div>
        <div style="margin-top:0.5rem;">
            <button type="button" class="aivory-request-code elementor-button elementor-size-md">Verstuur code</button>
        </div>
    </div>

    <!-- Step 2: verify -->
    <div class="aivory-booking-step" data-step="2" style="display:none;">
        <div class="elementor-field-type-text elementor-field-group elementor-column elementor-col-100 elementor-field-required elementor-mark-required">
            <label class="elementor-field-label" style="padding-top:10px;padding-bottom:3px;">Verificatiecode</label>
            <input type="text" name="code" inputmode="numeric" maxlength="4" class="aivory-code elementor-field elementor-size-md elementor-field-textual" required="required">
        </div>
        <div style="margin-top:0.5rem;">
            <button type="button" class="aivory-verify-code elementor-button elementor-size-md">Verifieer</button>
        </div>
    </div>

    <!-- Step 3: pick slot -->
    <div class="aivory-booking-step" data-step="3" style="display:none;">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:0.5rem;">
            <button type="button" class="aivory-prev-month elementor-button elementor-size-sm">&larr;</button>
            <strong class="aivory-month-label"></strong>
            <button type="button" class="aivory-next-month elementor-button elementor-size-sm">&rarr;</button>
        </div>
        <div class="aivory-days" style="display:flex;flex-wrap:wrap;gap:0.5rem;"></div>
        <div class="aivory-times" style="display:flex;flex-wrap:wrap;gap:0.5rem;margin-top:1rem;"></div>
    </div>

    <!-- Step 4: confirm -->
    <div class="aivory-booking-step" data-step="4" style="display:none;">
        <div class="aivory-summary" style="margin-bottom:1rem;"></div>
        <div class="elementor-field-type-textarea elementor-field-group elementor-column elementor-col-100">
            <label class="elementor-field-label" style="padding-top:10px;padding-bottom:3px;">Opmerkingen <small>(optioneel)</small></label>
            <textarea name="notes" maxlength="500" rows="3" class="aivory-notes elementor-field elementor-size-md elementor-field-textual"></textarea>
        </div>
        <div style="margin-top:0.5rem;">
            <button type="button" class="aivory-confirm elementor-button elementor-size-md">Bevestig afspraak</button>
        </div>
    </div>

    <!-- Confirmation -->
    <div class="aivory-booking-done" style="display:none;"></div>
</div>
<script>
    (function() {
        var root = document.getElementById('<?php echo esc_js($uid); ?>');
        if (!root) return;

        var ajaxUrl = <?php echo wp_json_encode($ajaxUrl); ?>;
        var nonce = <?php echo wp_json_encode($nonce); ?>;
        var state = {
            appointmentTypeId: null,
            email: '',
            token: '',
            month: null,
            selectedSlot: null,
            typeName: ''
        };

        function q(sel) {
            return root.querySelector(sel);
        }

        function post(action, data) {
            var body = new FormData();
            body.append('action', action);
            body.append('nonce', nonce);
            Object.keys(data).forEach(function(k) {
                body.append(k, data[k]);
            });
            return fetch(ajaxUrl, {
                    method: 'POST',
                    credentials: 'same-origin',
                    body: body
                })
                .then(function(r) {
                    return r.json();
                });
        }

        function showStep(n) {
            root.querySelectorAll('.aivory-booking-step').forEach(function(el) {
                el.style.display = (el.getAttribute('data-step') == n) ? '' : 'none';
            });
        }

        function message(text, ok) {
            var el = q('.aivory-booking-message');
            if (!text) {
                el.style.display = 'none';
                return;
            }
            el.textContent = text;
            el.style.display = '';
            el.style.border = '2px solid ' + (ok ? '#4CAF50' : '#f44336');
            el.style.background = ok ? '#f6fff6' : '#fff6f6';
            el.style.color = ok ? '#256029' : '#a12727';
        }

        function busy(btn, on) {
            btn.disabled = on;
            btn.style.opacity = on ? '0.6' : '';
        }

        function monthString(d) {
            return d.getFullYear() + '-' + ('0' + (d.getMonth() + 1)).slice(-2);
        }

        // Step 1: request code
        q('.aivory-request-code').addEventListener('click', function() {
            var type = q('.aivory-appointment-type').value;
            var email = q('.aivory-email').value.trim();
            var dob = q('.aivory-dob').value;
            if (!type || !email || !dob) {
                message('Vul alle velden in.', false);
                return;
            }
            state.appointmentTypeId = type;
            state.email = email;
            state.typeName = q('.aivory-appointment-type').selectedOptions[0].textContent;
            busy(this, true);
            var btn = this;
            post('aivory_booking_request_link', {
                email: email,
                dateOfBirth: dob
            }).then(function(res) {
                message(res.message || 'Als de gegevens kloppen ontvang je een code per e-mail.', true);
                showStep(2);
            }).catch(function() {
                message('Er is een fout opgetreden. Probeer het later opnieuw.', false);
            }).finally(function() {
                busy(btn, false);
            });
        });

        // Step 2: verify code
        q('.aivory-verify-code').addEventListener('click', function() {
            var code = q('.aivory-code').value.trim();
            if (!code) {
                message('Vul de verificatiecode in.', false);
                return;
            }
            busy(this, true);
            var btn = this;
            post('aivory_booking_verify_code', {
                    email: state.email,
                    code: code
                })
                .then(function(res) {
                    if (res.success && res.bookingToken) {
                        state.token = res.bookingToken;
                        message('', true);
                        state.month = new Date();
                        state.month.setDate(1);
                        showStep(3);
                        loadDays();
                    } else {
                        message(res.message || 'Ongeldige of verlopen code.', false);
                    }
                })
                .catch(function() {
                    message('Er is een fout opgetreden. Probeer het later opnieuw.', false);
                })
                .finally(function() {
                    busy(btn, false);
                });
        });

        // Step 3: month navigation + days
        q('.aivory-prev-month').addEventListener('click', function() {
            state.month.setMonth(state.month.getMonth() - 1);
            loadDays();
        });
        q('.aivory-next-month').addEventListener('click', function() {
            state.month.setMonth(state.month.getMonth() + 1);
            loadDays();
        });

        function loadDays() {
            q('.aivory-month-label').textContent =
                state.month.toLocaleDateString('nl-NL', {
                    month: 'long',
                    year: 'numeric'
                });
            var daysEl = q('.aivory-days');
            var timesEl = q('.aivory-times');
            daysEl.innerHTML = 'Laden...';
            timesEl.innerHTML = '';
            post('aivory_booking_available_days', {
                token: state.token,
                appointmentTypeId: state.appointmentTypeId,
                month: monthString(state.month)
            }).then(function(days) {
                daysEl.innerHTML = '';
                if (!Array.isArray(days) || !days.length) {
                    daysEl.textContent = 'Geen beschikbare dagen in deze maand.';
                    return;
                }
                days.forEach(function(day) {
                    var b = document.createElement('button');
                    b.type = 'button';
                    b.className = 'elementor-button elementor-size-sm';
                    b.textContent = new Date(day + 'T00:00:00').toLocaleDateString('nl-NL', {
                        weekday: 'short',
                        day: 'numeric',
                        month: 'short'
                    });
                    b.addEventListener('click', function() {
                        loadTimes(day);
                    });
                    daysEl.appendChild(b);
                });
            }).catch(function() {
                daysEl.textContent = 'Er is een fout opgetreden.';
            });
        }

        function loadTimes(day) {
            var timesEl = q('.aivory-times');
            timesEl.innerHTML = 'Laden...';
            post('aivory_booking_available_times', {
                token: state.token,
                appointmentTypeId: state.appointmentTypeId,
                date: day
            }).then(function(slots) {
                timesEl.innerHTML = '';
                if (!Array.isArray(slots) || !slots.length) {
                    timesEl.textContent = 'Geen beschikbare tijden op deze dag.';
                    return;
                }
                slots.forEach(function(slot) {
                    var b = document.createElement('button');
                    b.type = 'button';
                    b.className = 'elementor-button elementor-size-sm';
                    var time = String(slot.startTime).substring(11, 16);
                    b.textContent = time + (slot.practitionerName ? ' – ' + slot.practitionerName : '');
                    b.addEventListener('click', function() {
                        chooseSlot(slot, day);
                    });
                    timesEl.appendChild(b);
                });
            }).catch(function() {
                timesEl.textContent = 'Er is een fout opgetreden.';
            });
        }

        function chooseSlot(slot, day) {
            state.selectedSlot = slot;
            var dateLabel = new Date(day + 'T00:00:00').toLocaleDateString('nl-NL', {
                weekday: 'long',
                day: 'numeric',
                month: 'long',
                year: 'numeric'
            });
            var time = String(slot.startTime).substring(11, 16);
            q('.aivory-summary').innerHTML =
                '<strong>' + state.typeName + '</strong><br>' +
                dateLabel + ' om ' + time +
                (slot.practitionerName ? '<br>' + slot.practitionerName : '') +
                (slot.locationName ? '<br>' + slot.locationName : '');
            showStep(4);
        }

        // Step 4: confirm
        q('.aivory-confirm').addEventListener('click', function() {
            var slot = state.selectedSlot;
            if (!slot) return;
            busy(this, true);
            var btn = this;
            post('aivory_booking_confirm', {
                    token: state.token,
                    appointmentTypeId: state.appointmentTypeId,
                    startTime: slot.startTime,
                    practitionerId: slot.practitionerId,
                    locationId: slot.locationId,
                    notes: q('.aivory-notes').value
                }).then(function(res) {
                    if (res.success) {
                        showStep(0);
                        message('', true);
                        var done = q('.aivory-booking-done');
                        done.style.display = '';
                        done.innerHTML =
                            '<div style="border:2px solid #4CAF50;background:#f6fff6;color:#256029;padding:12px;border-radius:6px;">' +
                            '<strong>Afspraak bevestigd</strong><br>' +
                            (res.appointmentDate || '') + (res.appointmentTime ? ' om ' + res.appointmentTime : '') +
                            (res.practitionerName ? '<br>' + res.practitionerName : '') +
                            '</div>';
                    } else {
                        message(res.message || 'Dit tijdslot is niet meer beschikbaar. Kies een ander moment.', false);
                        showStep(3);
                        loadDays();
                    }
                }).catch(function() {
                    message('Er is een fout opgetreden. Probeer het later opnieuw.', false);
                })
                .finally(function() {
                    busy(btn, false);
                });
        });
    })();
</script>
