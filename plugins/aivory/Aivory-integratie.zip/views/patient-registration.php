<?php
require_once AIVORY_INCLUDES_PATH . 'core.php';
require_once AIVORY_INCLUDES_PATH . 'cloudflare.php';
$tenantId = getTenantId();
$locations = getTenantLocations();
$site_key = getCloudflareTurnstileSiteKey();
?>
<div>
    <?php if ($site_key != null): ?>
    <script src="https://challenges.cloudflare.com/turnstile/v0/api.js" defer></script>
    <?php endif; ?>
    <?php if (isset($_GET['aivory_status']) && $_GET['aivory_status'] === 'success') { ?>
        <div style="border: 2px solid #4CAF50; background: #f6fff6; color: #256029; padding: 12px 12px; border-radius: 6px; margin-bottom: 1rem;">
            <?php echo esc_html($_GET['aivory_message'] ?? 'Registratie is succesvol verzonden!'); ?>
        </div>
    <?php } elseif (isset($_GET['aivory_status']) && $_GET['aivory_status'] === 'api_error') { ?>
        <div style="border: 2px solid #f44336; background: #fff6f6; color: #a12727; padding: 12px 12px; border-radius: 6px; margin-bottom: 1rem;">
            <?php echo esc_html($_GET['aivory_message'] ?? 'Er is een fout opgetreden bij het registreren. Probeer het later opnieuw.'); ?>
        </div>
    <?php } ?>
    <form id="patient-registration-form" method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
        <?php wp_nonce_field('patient_registration_form_action', 'patient_registration_form_nonce'); ?>
        <input type="hidden" name="action" value="patient_registration_form_submit">
        <div style="<?php if (count($locations) < 2) echo 'display:none;'; ?>" class="elementor-field-type-text elementor-field-group elementor-column elementor-col-100 elementor-field-required elementor-mark-required">
            <label class="elementor-field-label" style="padding-top: 10px;padding-bottom: 3px;">Locatie</label>
            <select name="location" id="location" class="elementor-field elementor-size-md elementor-field-textual" required="required">
                <?php foreach ($locations as $location) { ?>
                    <option value="<?php echo $location['id']; ?>"><?php echo $location['name']; ?></option>
                <?php } ?>
            </select>
        </div>
        <div class="elementor-field-type-text elementor-field-group elementor-column elementor-col-100 elementor-field-required elementor-mark-required">
            <label class="elementor-field-label" style="padding-top: 10px;padding-bottom: 3px;">Voornaam</label>
            <input name="firstName" type="text" class="elementor-field elementor-size-md elementor-field-textual" required="required">
        </div>
        <div class="elementor-field-type-text elementor-field-group elementor-column elementor-col-100 elementor-field-required elementor-mark-required">
            <label class="elementor-field-label" style="padding-top: 10px;padding-bottom: 3px;">Achternaam</label>
            <input name="lastName" type="text" class="elementor-field elementor-size-md elementor-field-textual" required="required">
        </div>
        <div class="elementor-field-type-text elementor-field-group elementor-column elementor-col-100 elementor-field-required elementor-mark-required">
            <label class="elementor-field-label" style="padding-top: 10px;padding-bottom: 3px;">Geboortedatum</label>
            <input name="dateOfBirth" type="date" class="elementor-field elementor-size-md elementor-field-textual" required="required">
        </div>
        <div class="elementor-field-type-text elementor-field-group elementor-column elementor-col-100 elementor-field-required elementor-mark-required">
            <label class="elementor-field-label" style="padding-top: 10px;padding-bottom: 3px;">Geslacht</label>
            <select name="gender" id="gender" class="elementor-field elementor-size-md elementor-field-textual" required="required">
                <option value="" disabled selected>Geslacht</option>
                <option value="M">Man</option>
                <option value="F">Vrouw</option>
                <option value="X">Overig</option>
            </select>
        </div>
        <div class="elementor-field-type-text elementor-field-group elementor-column elementor-col-100 elementor-field-required elementor-mark-required">
            <label class="elementor-field-label" style="padding-top: 10px;padding-bottom: 3px;">E-mail</label>
            <input name="email" type="email" class="elementor-field elementor-size-md elementor-field-textual" required="required">
        </div>
        <div class="elementor-field-type-text elementor-field-group elementor-column elementor-col-100 elementor-field-required elementor-mark-required">
            <label class="elementor-field-label" style="padding-top: 10px;padding-bottom: 3px;">Telefoon</label>
            <input name="phone" type="tel" class="elementor-field elementor-size-md elementor-field-textual" required="required">
        </div>
        <div class="elementor-field-type-text elementor-field-group elementor-column elementor-col-100 elementor-field-required elementor-mark-required">
            <label class="elementor-field-label" style="padding-top: 10px;padding-bottom: 3px;">Straat</label>
            <input name="street" type="text" class="elementor-field elementor-size-md elementor-field-textual" required="required">
        </div>
        <div class="elementor-field-type-text elementor-field-group elementor-column elementor-col-100 elementor-field-required elementor-mark-required">
            <label class="elementor-field-label" style="padding-top: 10px;padding-bottom: 3px;">Postcode</label>
            <input name="postalCode" type="text" class="elementor-field elementor-size-md elementor-field-textual" required="required">
        </div>
        <div class="elementor-field-type-text elementor-field-group elementor-column elementor-col-100 elementor-field-required elementor-mark-required">
            <label class="elementor-field-label" style="padding-top: 10px;padding-bottom: 3px;">Stad</label>
            <input name="city" type="text" class="elementor-field elementor-size-md elementor-field-textual" required="required">
        </div>
        <?php if ($bsnEnabled) : ?>
        <div class="elementor-field-type-text elementor-field-group elementor-column elementor-col-100">
            <label class="elementor-field-label" style="padding-top: 10px;padding-bottom: 3px;">BSN <small>(Burgerservicenummer)</small></label>
            <input name="bsn" type="text" class="elementor-field elementor-size-md elementor-field-textual">
        </div>
        <?php endif; ?>
        <?php if ($site_key != null): ?>
        <div style="margin-top: 1rem;" class="cf-turnstile" data-sitekey="<?php echo esc_attr($site_key); ?>" data-language="nl" data-error-callback="aivoryTurnstileError"></div>
        <?php endif; ?>
        <div style="margin-top: 0.5rem;">
            <button class="elementor-button elementor-size-md" type="submit">Verzenden</button>
        </div>
    </form>
    <script>
        function aivoryTurnstileError(code) {
            fetch('https://api.aivory.nl/public/captcha-error/<?= $tenantId ?>', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    errorCode: String(code),
                    hostname: location.hostname
                })
            }).catch(function() {});
        }
    </script>
</div> 
