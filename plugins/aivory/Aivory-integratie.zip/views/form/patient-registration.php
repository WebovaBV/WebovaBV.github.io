<div class="elementor-control elementor-control-_position elementor-control-type-select elementor-label-inline elementor-control-separator-before">
    <div class="elementor-control-content">
        <div class="elementor-control-field ">
            <label for="elementor-control-default-c2598" class="elementor-control-title">BSN invulveld</label>
            <div class="elementor-control-input-wrapper elementor-control-unit-5">
                <select name="<?php echo $this->get_field_name('bsnEnabled'); ?>" id="<?php echo $this->get_field_id('bsnEnabled'); ?>">
                    <option value="off" <?php echo $bsnEnabled ? '' : 'selected'; ?>>Uit</option>
                    <option value="on" <?php echo $bsnEnabled ? 'selected' : ''; ?>>Aan</option>
                </select>
            </div>
        </div>
    </div>
</div>
