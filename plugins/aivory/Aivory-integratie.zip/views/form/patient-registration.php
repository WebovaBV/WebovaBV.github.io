<div class="elementor-control elementor-control-_position elementor-control-type-select elementor-label-inline elementor-control-separator-before">
    <div class="elementor-control-content" style="margin-bottom: 1rem;">
        <h5>BSN</h5>
        <div class="elementor-control-field ">
            <label for="elementor-control-default-c2598" class="elementor-control-title">Invulveld</label>
            <div class="elementor-control-input-wrapper elementor-control-unit-5">
                <select name="<?php echo $this->get_field_name('bsnEnabled'); ?>" id="<?php echo $this->get_field_id('bsnEnabled'); ?>">
                    <option value="off" <?php echo $bsnEnabled ? '' : 'selected'; ?>>Uit</option>
                    <option value="on" <?php echo $bsnEnabled ? 'selected' : ''; ?>>Aan</option>
                </select>
            </div>
        </div>
        <div class="elementor-control-field ">
            <label for="elementor-control-default-c2598" class="elementor-control-title">Verplicht</label>
            <div class="elementor-control-input-wrapper elementor-control-unit-5">
                <select name="<?php echo $this->get_field_name('bsnRequired'); ?>" id="<?php echo $this->get_field_id('bsnRequired'); ?>">
                    <option value="off" <?php echo $bsnRequired ? '' : 'selected'; ?>>Nee</option>
                    <option value="on" <?php echo $bsnRequired ? 'selected' : ''; ?>>Ja</option>
                </select>
            </div>
        </div>
    </div>
    <div class="elementor-control-content">
        <h5>Verzekeringsnummer</h5>
        <div class="elementor-control-field ">
            <label for="elementor-control-default-c2598" class="elementor-control-title">Invulveld</label>
            <div class="elementor-control-input-wrapper elementor-control-unit-5">
                <select name="<?php echo $this->get_field_name('insuranceEnabled'); ?>" id="<?php echo $this->get_field_id('insuranceEnabled'); ?>">
                    <option value="off" <?php echo $insuranceEnabled ? '' : 'selected'; ?>>Uit</option>
                    <option value="on" <?php echo $insuranceEnabled ? 'selected' : ''; ?>>Aan</option>
                </select>
            </div>
        </div>
        <div class="elementor-control-field ">
            <label for="elementor-control-default-c2598" class="elementor-control-title">Verplicht</label>
            <div class="elementor-control-input-wrapper elementor-control-unit-5">
                <select name="<?php echo $this->get_field_name('insuranceRequired'); ?>" id="<?php echo $this->get_field_id('insuranceRequired'); ?>">
                    <option value="off" <?php echo $insuranceRequired ? '' : 'selected'; ?>>Nee</option>
                    <option value="on" <?php echo $insuranceRequired ? 'selected' : ''; ?>>Ja</option>
                </select>
            </div>
        </div>
    </div>
</div>
