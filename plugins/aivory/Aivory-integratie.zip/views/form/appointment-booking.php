<div class="elementor-control elementor-control-type-raw_html">
    <div class="elementor-control-content">
        <p>De Aivory afspraak-widget heeft geen instellingen. Zorg dat het klantnummer is ingevuld bij Instellingen &rarr; Aivory.</p>
    </div>
</div>
