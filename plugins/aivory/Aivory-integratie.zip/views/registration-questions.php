<?php

/**
 * Renders the dynamic registration form questions.
 * Expects $form (the schema from getTenantRegistrationForm()) in scope.
 */

require_once AIVORY_INCLUDES_PATH . 'helper.php';

if (!function_exists('aivoryRenderRegistrationQuestion')) {
    function aivoryRenderRegistrationQuestion(array $question): void
    {
        $id = $question['id'] ?? '';
        if ($id === '') {
            return;
        }

        $label = $question['question'] ?? '';
        $helpText = $question['helpText'] ?? '';
        $type = $question['type'] ?? 'text';
        $options = $question['options'] ?? [];
        $allowMultiple = !empty($question['allowMultiple']);
        $isRequired = !empty($question['isRequired']);
        $inputId = 'question-' . $id;
        $name = 'formAnswers[' . $id . ']';

        $requiredClass = $isRequired ? ' elementor-field-required elementor-mark-required' : '';
        $requiredAttr = $isRequired ? ' required="required"' : '';

        $groupAttrs = 'data-question-id="' . esc_attr($id) . '"';
        if (!empty($question['visibleWhenQuestionId'])) {
            $groupAttrs .= ' data-visible-when-question="' . esc_attr($question['visibleWhenQuestionId']) . '"';
            $groupAttrs .= ' data-visible-when-value="' . esc_attr($question['visibleWhenQuestionValue'] ?? '') . '"';
            $groupAttrs .= ' data-visible-when-operator="' . esc_attr($question['visibleWhenOperator'] ?? 'eq') . '"';
        }
        ?>
        <div class="elementor-field-type-text elementor-field-group elementor-column elementor-col-100<?php echo $requiredClass; ?>" <?php echo $groupAttrs; ?>>
            <label for="<?php echo esc_attr($inputId); ?>" class="elementor-field-label" style="display:block;padding-top: 10px;padding-bottom: 3px;">
                <?php echo esc_html($label); ?>
            </label>
            <?php if ($helpText !== '') : ?>
                <small style="display:block;color:#666;padding-bottom:3px;"><?php echo esc_html($helpText); ?></small>
            <?php endif; ?>
            <?php
            switch ($type) {
                case 'textarea':
                    ?>
                    <textarea id="<?php echo esc_attr($inputId); ?>" name="<?php echo esc_attr($name); ?>" class="elementor-field elementor-size-md elementor-field-textual"<?php echo $requiredAttr; ?>></textarea>
                    <?php
                    break;

                case 'select':
                    ?>
                    <select id="<?php echo esc_attr($inputId); ?>" name="<?php echo esc_attr($name); ?>" class="elementor-field elementor-size-md elementor-field-textual"<?php echo $requiredAttr; ?>>
                        <option value="" disabled selected><?php echo esc_html($label); ?></option>
                        <?php foreach ($options as $option) : ?>
                            <option value="<?php echo esc_attr($option); ?>"><?php echo esc_html($option); ?></option>
                        <?php endforeach; ?>
                    </select>
                    <?php
                    break;

                case 'yes_no':
                    $options = ['Ja', 'Nee'];
                    // fall through to radio rendering below
                case 'radio':
                case 'checkbox':
                    $multiple = ($allowMultiple || $type === 'checkbox') && $type !== 'yes_no';
                    $inputType = $multiple ? 'checkbox' : 'radio';
                    $optionName = $multiple ? $name . '[]' : $name;
                    ?>
                    <div style="width:100%;flex-basis:100%;clear:both;">
                        <?php foreach ($options as $index => $option) :
                            $optionId = $inputId . '-' . $index;
                            ?>
                            <div style="padding: 2px 0;">
                                <input type="<?php echo $inputType; ?>" id="<?php echo esc_attr($optionId); ?>" name="<?php echo esc_attr($optionName); ?>" value="<?php echo esc_attr($option); ?>"<?php echo $multiple ? '' : $requiredAttr; ?>>
                                <label for="<?php echo esc_attr($optionId); ?>" style="display:inline;font-weight:normal;"><?php echo esc_html($option); ?></label>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    <?php
                    break;

                case 'scale':
                    $min = isset($question['scaleMin']) ? (int) $question['scaleMin'] : 1;
                    $max = isset($question['scaleMax']) ? (int) $question['scaleMax'] : 10;
                    ?>
                    <select id="<?php echo esc_attr($inputId); ?>" name="<?php echo esc_attr($name); ?>" class="elementor-field elementor-size-md elementor-field-textual"<?php echo $requiredAttr; ?>>
                        <option value="" disabled selected><?php echo esc_html($label); ?></option>
                        <?php for ($i = $min; $i <= $max; $i++) : ?>
                            <option value="<?php echo esc_attr($i); ?>"><?php echo esc_html($i); ?></option>
                        <?php endfor; ?>
                    </select>
                    <?php
                    break;

                case 'number':
                case 'date':
                case 'email':
                default:
                    $inputType = in_array($type, ['number', 'date', 'email'], true) ? $type : 'text';
                    ?>
                    <input id="<?php echo esc_attr($inputId); ?>" name="<?php echo esc_attr($name); ?>" type="<?php echo esc_attr($inputType); ?>" class="elementor-field elementor-size-md elementor-field-textual"<?php echo $requiredAttr; ?>>
                    <?php
                    break;
            }
            ?>
            <?php if (!empty($question['requiresFollowUp'])) : ?>
                <input name="formAnswersFollowUp[<?php echo esc_attr($id); ?>]" type="text" placeholder="<?php echo esc_attr($question['followUpText'] ?? ''); ?>" class="elementor-field elementor-size-md elementor-field-textual" style="margin-top: 6px;">
            <?php endif; ?>
        </div>
        <?php
    }
}

$aivoryFormQuestions = getRegistrationFormQuestions($form ?? []);
if (empty($aivoryFormQuestions)) {
    return;
}
?>
<?php if (!empty($form['formLoadToken'])) : ?>
    <input type="hidden" name="formLoadToken" value="<?php echo esc_attr($form['formLoadToken']); ?>">
<?php endif; ?>
<?php foreach ($aivoryFormQuestions as $question) : ?>
    <?php aivoryRenderRegistrationQuestion($question); ?>
<?php endforeach; ?>
<script>
    (function () {
        var form = document.getElementById('patient-registration-form');
        if (!form) return;

        function currentValue(questionId) {
            var inputs = form.querySelectorAll('[name="formAnswers[' + questionId + ']"], [name="formAnswers[' + questionId + '][]"]');
            for (var i = 0; i < inputs.length; i++) {
                var input = inputs[i];
                if (input.type === 'checkbox' || input.type === 'radio') {
                    if (input.checked) return input.value;
                } else if (input.value !== '') {
                    return input.value;
                }
            }
            return '';
        }

        function matches(actual, expected, operator) {
            var a = parseFloat(actual), b = parseFloat(expected);
            var numeric = !isNaN(a) && !isNaN(b);
            switch (operator) {
                case 'ne': return actual !== expected;
                case 'lt': return numeric && a < b;
                case 'lte': return numeric && a <= b;
                case 'gt': return numeric && a > b;
                case 'gte': return numeric && a >= b;
                default: return actual === expected;
            }
        }

        var conditionalGroups = form.querySelectorAll('[data-visible-when-question]');

        function evaluate() {
            conditionalGroups.forEach(function (group) {
                var actual = currentValue(group.getAttribute('data-visible-when-question'));
                var expected = group.getAttribute('data-visible-when-value');
                var operator = group.getAttribute('data-visible-when-operator');
                var visible = matches(actual, expected, operator);
                group.style.display = visible ? '' : 'none';
                group.querySelectorAll('input, select, textarea').forEach(function (field) {
                    field.disabled = !visible;
                });
            });
        }

        form.addEventListener('change', evaluate);
        form.addEventListener('input', evaluate);
        evaluate();
    })();
</script>
