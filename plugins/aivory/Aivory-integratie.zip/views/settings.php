<?php
$tenantId = esc_attr(get_option('aivory_tenant_id', null));
$site_key = esc_attr(get_option('aivory_cloudflare_site_key', null));
$secret_key = esc_attr(get_option('aivory_cloudflare_secret_key', null));
?>
<div class="wrap">
    <h1>Aivory Integratie Instellingen</h1>
    <form method="post" action="options.php">
        <div>
            <h3>Aivory Klantnummer</h3>
            <div style="padding-bottom: 1rem; margin-left:2rem;">
                <p class="description">Voer hier uw Aivory klantnummer in.</p>
                <input type="text" placeholder="Aivory Klantnummer" name="aivory_tenant_id" value="<?= $tenantId ?>" size="60" />
            </div>
        </div>

        <div>
            <h3>Cloudflare Turnstile</h3>
            <div>
                <div style="padding-bottom: 1rem; margin-left:2rem;">
                    <p class="description">Voer hier uw Cloudflare Site Key in.</p>
                    <input type="text" placeholder="Cloudflare Site Key" name="aivory_cloudflare_site_key" value="<?= $site_key ?>" size="60" />
                </div>
                <div style="padding-bottom: 1rem; margin-left:2rem;">
                    <p class="description">Voer hier uw Cloudflare Secret Key in.</p>
                    <input type="text" placeholder="Cloudflare Secret Key" name="aivory_cloudflare_secret_key" value="<?= $secret_key ?>" size="60" />
                </div>
            </div>
        </div>
        <?php settings_fields('aivory_options'); do_settings_sections('aivory_options'); submit_button(); ?>
    </form>
    <hr>
    <div>
        <h3>Cache</h3>
        <?php if (isset($_GET['aivory_cache_cleared'])): ?>
            <div class="notice notice-success is-dismissible">
                <p>De cache van deze plugin is geleegd.</p>
            </div>
        <?php endif; ?>
        <div style="padding-bottom: 1rem; margin-left:2rem;">
            <p class="description">Leeg de gecachete locaties en afspraaktypes van deze plugin. Doe dit na het wijzigen van het klantnummer of als gegevens verouderd lijken.</p>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <input type="hidden" name="action" value="aivory_clear_cache">
                <?php wp_nonce_field('aivory_clear_cache_action', 'aivory_clear_cache_nonce'); ?>
                <?php submit_button('Cache legen', 'secondary', 'submit', false); ?>
            </form>
        </div>
    </div>
    <hr>
    <div>
        <h3>Debug</h3>
        <div style="margin-left:2rem;">
            <b>Debug modus:</b> <small><?= WP_DEBUG ? 'Aan' : 'Uit' ?></small><br>
            <b>API URL:</b> <small><?= AIVORY_API_URL ?></small><br>
        </div>
    </div>
</div>
