<?php
$tenantId = esc_attr(get_option('aivory_tenant_id', null));
$site_key = esc_attr(get_option('aivory_cloudflare_site_key', null));
$secret_key = esc_attr(get_option('aivory_cloudflare_secret_key', null));
?>
<div class="wrap">
    <h1>Aivory Integratie Instellingen</h1>
    <form method="post" action="options.php">
        <div>
            <h3>Aivory Klantnummer</h3>
            <div style="padding-bottom: 1rem; margin-left:2rem;">
                <p class="description">Voer hier uw Aivory klantnummer in.</p>
                <input type="text" placeholder="Aivory Klantnummer" name="aivory_tenant_id" value="<?= $tenantId ?>" size="60" />
            </div>
        </div>

        <div>
            <h3>Cloudflare Turnstile</h3>
            <div>
                <div style="padding-bottom: 1rem; margin-left:2rem;">
                    <p class="description">Voer hier uw Cloudflare Site Key in.</p>
                    <input type="text" placeholder="Cloudflare Site Key" name="aivory_cloudflare_site_key" value="<?= $site_key ?>" size="60" />
                </div>
                <div style="padding-bottom: 1rem; margin-left:2rem;">
                    <p class="description">Voer hier uw Cloudflare Secret Key in.</p>
                    <input type="text" placeholder="Cloudflare Secret Key" name="aivory_cloudflare_secret_key" value="<?= $secret_key ?>" size="60" />
                </div>
            </div>
        </div>
        <?php settings_fields('aivory_options'); do_settings_sections('aivory_options'); submit_button(); ?>
    </form>
</div>
