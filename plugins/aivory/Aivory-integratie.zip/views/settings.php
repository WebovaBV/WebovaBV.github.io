<?php
$tenantId = esc_attr(get_option('aivory_tenant_id', null));
$site_key = esc_attr(get_option('aivory_cloudflare_site_key', null));
?>
<div class="wrap">
    <h1>Aivory Integratie Instellingen</h1>
    <form method="post" action="options.php">
        <div>
            <h3>Aivory Klantnummer</h3>
            <div style="padding-bottom: 1rem; margin-left:2rem;">
                <p class="description">Voer hier uw Aivory klantnummer in.</p>
                <input type="text" placeholder="Aivory Klantnummer" name="aivory_tenant_id" value="<?= $tenantId ?>" size="60" />
                <a href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=aivory_test_branding'), 'aivory_test_branding_action')); ?>" class="button button-secondary">Test API verbinding</a>
                <?php
                $branding_result = get_transient('aivory_branding_test_result');
                delete_transient('aivory_branding_test_result');
                if ($branding_result !== false):
                ?>
                    <?php if (empty($branding_result)): ?>
                        <div class="notice notice-warning inline" style="margin:1rem 0;">
                            <p>Geen verbinding met de Aivory API. Controleer het klantnummer.</p>
                        </div>
                    <?php else: ?>
                        <table class="widefat striped" style="max-width:40rem; margin-top:1rem;">
                            <tbody>
                                <?php foreach ($branding_result as $key => $value): ?>
                                    <tr>
                                        <th scope="row" style="width:14rem;"><?= esc_html($key) ?></th>
                                        <td>
                                            <?php if (is_bool($value)): ?>
                                                <?= $value ? 'Ja' : 'Nee' ?>
                                            <?php elseif (is_array($value)): ?>
                                                <?= empty($value) ? '<em>leeg</em>' : esc_html(wp_json_encode($value, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)) ?>
                                            <?php elseif (is_string($value) && preg_match('/^#[0-9a-fA-F]{3,8}$/', $value)): ?>
                                                <span style="display:inline-block; width:1rem; height:1rem; vertical-align:middle; border:1px solid #dcdcde; background:<?= esc_attr($value) ?>;"></span>
                                                <code><?= esc_html($value) ?></code>
                                            <?php else: ?>
                                                <?= $value === '' || $value === null ? '<em>leeg</em>' : esc_html((string) $value) ?>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>

        <div>
            <h3>Cloudflare Turnstile</h3>
            <div>
                <div style="padding-bottom: 1rem; margin-left:2rem;">
                    <p class="description">Voer hier uw Cloudflare Site Key in.</p>
                    <input type="text" placeholder="Cloudflare Site Key" name="aivory_cloudflare_site_key" value="<?= $site_key ?>" size="60" />
                </div>
            </div>
        </div>
        <?php settings_fields('aivory_options'); do_settings_sections('aivory_options'); submit_button(); ?>
    </form>
    <hr>
    <div>
        <h3>Cache</h3>
        <?php if (isset($_GET['aivory_cache_cleared'])): ?>
            <div class="notice notice-success is-dismissible">
                <p>De cache van deze plugin is geleegd.</p>
            </div>
        <?php endif; ?>
        <div style="padding-bottom: 1rem; margin-left:2rem;">
            <p class="description">Leeg de gecachete locaties en afspraaktypes van deze plugin. Doe dit na het wijzigen van het klantnummer of als gegevens verouderd lijken.</p>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <input type="hidden" name="action" value="aivory_clear_cache">
                <?php wp_nonce_field('aivory_clear_cache_action', 'aivory_clear_cache_nonce'); ?>
                <?php submit_button('Cache legen', 'secondary', 'submit', false); ?>
            </form>
        </div>
    </div>
    <hr>
    <div>
        <h3>Debug</h3>
        <div style="margin-left:2rem;">
            <b>Debug modus:</b> <small><?= WP_DEBUG ? 'Aan' : 'Uit' ?></small><br>
            <b>Timezone:</b> <small><?= wp_timezone()->getName() ?></small><br>
            <b>API URL:</b> <small><?= AIVORY_API_URL ?></small><br>
        </div>
    </div>
</div>
