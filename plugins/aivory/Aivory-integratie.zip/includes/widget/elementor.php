<?php

function aivory_register_elementor_category($elements_manager)
{
    $elements_manager->add_category('aivory-widgets', [
        'title' => __('Aivory', 'wpb_widget_domain'),
        'icon' => 'eicon-plug',
    ]);
}

function aivory_register_elementor_widgets($widgets_manager)
{
    require_once AIVORY_INCLUDES_PATH . 'widget/elementor/patient-registration-widget.php';
    require_once AIVORY_INCLUDES_PATH . 'widget/elementor/appointment-booking-widget.php';

    $widgets_manager->register(new Aivory_Patient_Registration_Widget());
    $widgets_manager->register(new Aivory_Appointment_Booking_Widget());
}

add_action('elementor/elements/categories_registered', 'aivory_register_elementor_category');
add_action('elementor/widgets/register', 'aivory_register_elementor_widgets');
