<?php
use Elementor\Controls_Manager;
use Elementor\Widget_Base;

class Aivory_Appointment_Booking_Widget extends Widget_Base
{
    public function get_name()
    {
        return 'aivory_appointment_booking';
    }

    public function get_title()
    {
        return __('Afspraak maken', 'wpb_widget_domain');
    }

    public function get_icon()
    {
        return 'eicon-calendar';
    }

    public function get_categories()
    {
        return ['aivory-widgets'];
    }

    public function get_keywords()
    {
        return ['aivory', 'afspraak', 'boeken', 'agenda'];
    }

    protected function register_controls()
    {
        $this->start_controls_section('info_section', [
            'label' => __('Instellingen', 'wpb_widget_domain'),
            'tab' => Controls_Manager::TAB_CONTENT,
        ]);
        $this->add_control('info', [
            'type' => Controls_Manager::RAW_HTML,
            'raw' => __('Deze widget heeft geen instellingen. Zorg dat het klantnummer is ingevuld bij Instellingen &rarr; Aivory.', 'wpb_widget_domain'),
            'content_classes' => 'elementor-descriptor',
        ]);
        $this->end_controls_section();
    }

    protected function render()
    {
        require AIVORY_VIEWS_PATH . 'appointment-booking.php';
    }
}
