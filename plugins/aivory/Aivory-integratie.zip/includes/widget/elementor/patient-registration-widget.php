<?php
use Elementor\Controls_Manager;
use Elementor\Widget_Base;

class Aivory_Patient_Registration_Widget extends Widget_Base
{
    public function get_name()
    {
        return 'aivory_patient_registration';
    }

    public function get_title()
    {
        return __('Patiëntenregistratie', 'wpb_widget_domain');
    }

    public function get_icon()
    {
        return 'eicon-form-horizontal';
    }

    public function get_categories()
    {
        return ['aivory-widgets'];
    }

    public function get_keywords()
    {
        return ['aivory', 'registratie', 'patiënt', 'formulier'];
    }

    protected function register_controls()
    {
        $this->start_controls_section('bsn_section', [
            'label' => __('BSN', 'wpb_widget_domain'),
            'tab' => Controls_Manager::TAB_CONTENT,
        ]);
        $this->add_toggle('bsnEnabled', __('Invulveld tonen', 'wpb_widget_domain'));
        $this->add_toggle('bsnRequired', __('Verplicht', 'wpb_widget_domain'));
        $this->end_controls_section();

        $this->start_controls_section('insurance_section', [
            'label' => __('Verzekeringsnummer', 'wpb_widget_domain'),
            'tab' => Controls_Manager::TAB_CONTENT,
        ]);
        $this->add_toggle('insuranceEnabled', __('Invulveld tonen', 'wpb_widget_domain'));
        $this->add_toggle('insuranceRequired', __('Verplicht', 'wpb_widget_domain'));
        $this->end_controls_section();

        $this->start_controls_section('redirect_section', [
            'label' => __('Doorverwijzing', 'wpb_widget_domain'),
            'tab' => Controls_Manager::TAB_CONTENT,
        ]);
        $this->add_control('redirectUrl', [
            'label' => __('URL na verzenden', 'wpb_widget_domain'),
            'type' => Controls_Manager::URL,
            'options' => false,
            'placeholder' => 'https://voorbeeld.nl/bedankt',
            'description' => __('Bij succesvol verzenden gaat de bezoeker naar deze URL. <br>Zonder URL blijft de bezoeker op dezelfde pagina en ziet een succesmelding.', 'wpb_widget_domain'),
        ]);
        $this->end_controls_section();
    }

    protected function render()
    {
        $settings = $this->get_settings_for_display();
        $bsnEnabled = $this->is_on($settings, 'bsnEnabled');
        $bsnRequired = $this->is_on($settings, 'bsnRequired');
        $insuranceEnabled = $this->is_on($settings, 'insuranceEnabled');
        $insuranceRequired = $this->is_on($settings, 'insuranceRequired');
        $redirectUrl = normalizePatientRegistrationRedirectUrl($settings['redirectUrl']['url'] ?? '');

        require AIVORY_VIEWS_PATH . 'patient-registration.php';
    }

    private function add_toggle(string $id, string $label)
    {
        $this->add_control($id, [
            'label' => $label,
            'type' => Controls_Manager::SWITCHER,
            'label_on' => __('Aan', 'wpb_widget_domain'),
            'label_off' => __('Uit', 'wpb_widget_domain'),
            'return_value' => 'on',
            'default' => '',
        ]);
    }

    private function is_on(array $settings, string $id): bool
    {
        return ($settings[$id] ?? '') === 'on';
    }
}
