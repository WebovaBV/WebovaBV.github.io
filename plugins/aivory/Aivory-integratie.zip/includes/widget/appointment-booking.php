<?php
require_once AIVORY_INCLUDES_PATH . 'core.php';

class appointmentBooking extends WP_Widget
{

    public function __construct()
    {
        parent::__construct(
            'aivory_appointment_booking', // Base ID
            __('Aivory Afspraak maken', 'wpb_widget_domain'),
            array('customize_selective_refresh' => false)
        );
    }

    public function widget($args, $instance)
    {
        require_once AIVORY_VIEWS_PATH . 'appointment-booking.php';
    }

    public function form($instance)
    {
        require_once AIVORY_VIEWS_PATH . 'form/appointment-booking.php';
    }
}

function register_appointment_booking_widget()
{
    register_widget('appointmentBooking');
}

function aivory_booking_verify_request()
{
    check_ajax_referer('aivory_booking', 'nonce');
}

function aivory_booking_token()
{
    return isset($_POST['token']) ? sanitize_text_field($_POST['token']) : '';
}

function handle_aivory_booking_request_link()
{
    aivory_booking_verify_request();
    $email = sanitize_email($_POST['email'] ?? '');
    $dateOfBirth = sanitize_text_field($_POST['dateOfBirth'] ?? '');
    wp_send_json(aivoryBookingRequestLink($email, $dateOfBirth));
}

function handle_aivory_booking_verify_code()
{
    aivory_booking_verify_request();
    $email = sanitize_email($_POST['email'] ?? '');
    $code = sanitize_text_field($_POST['code'] ?? '');
    wp_send_json(aivoryBookingVerifyCode($email, $code));
}

function handle_aivory_booking_available_days()
{
    aivory_booking_verify_request();
    $appointmentTypeId = intval($_POST['appointmentTypeId'] ?? 0);
    $month = preg_replace('/[^0-9\-]/', '', $_POST['month'] ?? '');
    wp_send_json(aivoryBookingAvailableDays(aivory_booking_token(), $appointmentTypeId, $month));
}

function handle_aivory_booking_available_times()
{
    aivory_booking_verify_request();
    $appointmentTypeId = intval($_POST['appointmentTypeId'] ?? 0);
    $date = preg_replace('/[^0-9\-]/', '', $_POST['date'] ?? '');
    wp_send_json(aivoryBookingAvailableTimes(aivory_booking_token(), $appointmentTypeId, $date));
}

function handle_aivory_booking_confirm()
{
    aivory_booking_verify_request();
    $payload = [
        'appointmentTypeId' => intval($_POST['appointmentTypeId'] ?? 0),
        'startTime' => sanitize_text_field($_POST['startTime'] ?? ''),
        'practitionerId' => sanitize_text_field($_POST['practitionerId'] ?? ''),
        'locationId' => intval($_POST['locationId'] ?? 0),
    ];
    if (!empty($_POST['notes'])) {
        $payload['notes'] = sanitize_textarea_field($_POST['notes']);
    }
    wp_send_json(aivoryBookingConfirm(aivory_booking_token(), $payload));
}

add_action('widgets_init', 'register_appointment_booking_widget');

$aivory_booking_ajax_actions = [
    'aivory_booking_request_link' => 'handle_aivory_booking_request_link',
    'aivory_booking_verify_code' => 'handle_aivory_booking_verify_code',
    'aivory_booking_available_days' => 'handle_aivory_booking_available_days',
    'aivory_booking_available_times' => 'handle_aivory_booking_available_times',
    'aivory_booking_confirm' => 'handle_aivory_booking_confirm',
];
foreach ($aivory_booking_ajax_actions as $action => $handler) {
    add_action("wp_ajax_$action", $handler);
    add_action("wp_ajax_nopriv_$action", $handler);
}
