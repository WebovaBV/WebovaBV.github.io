<?php
require_once AIVORY_INCLUDES_PATH . 'core.php';

class patientRegistration extends WP_Widget
{

    public function __construct()
    {
        parent::__construct(
            'aivory_patient_registration', // Base ID
            __('Aivory Patiëntenregistratie', 'wpb_widget_domain'),
            array('customize_selective_refresh' => false)
        );
    }

    public function widget($args, $instance)
    {
        $bsnEnabled = ($instance['bsnEnabled'] ?? 'off') === 'on' ? true : false;
        require_once AIVORY_VIEWS_PATH . 'patient-registration.php';
    }

    public function form($instance) {
        $bsnEnabled = ($instance['bsnEnabled'] ?? 'off') === 'on' ? true : false;
        require_once AIVORY_VIEWS_PATH . 'form/patient-registration.php';
    }
}

function register_patient_registration_widget()
{
    register_widget('patientRegistration');
}

function handle_patient_registration_form_submission()
{
    if (!isset($_POST['patient_registration_form_nonce'])) {
        wp_safe_redirect(add_query_arg(['aivory_status' => 'api_error'], wp_get_referer()));
        exit;
    }
    $payload = [
        "firstName" => sanitize_text_field($_POST['firstName']),
        "lastName" => sanitize_text_field($_POST['lastName']),
        "dateOfBirth" => sanitize_text_field($_POST['dateOfBirth']),
        "gender" => sanitize_text_field($_POST['gender']),
        "email" => sanitize_email($_POST['email']),
        "phone" => sanitize_text_field($_POST['phone']),
        "street" => sanitize_text_field($_POST['street']),
        "postalCode" => sanitize_text_field($_POST['postalCode']),
        "city" => sanitize_text_field($_POST['city']),
        "bsn" => isset($_POST['bsn']) ? sanitize_text_field($_POST['bsn']) : null,
        "locationId" => sanitize_text_field($_POST['location']),
        "acquisitionSource" => "WEBSITE",
        "captchaToken" => isset($_POST['cf-turnstile-response']) ? sanitize_text_field($_POST['cf-turnstile-response']) : null 
    ];
    $response = submitPatientRegistration($payload);
    if ($response['success']) {
        wp_safe_redirect(add_query_arg(['aivory_status' => 'success','aivory_message' => $response['message']], wp_get_referer()));
    } else {
        wp_safe_redirect(add_query_arg(['aivory_status' => 'api_error','aivory_message' => $response['message']], wp_get_referer()));
    }
    exit;
}

add_action('widgets_init', 'register_patient_registration_widget');
add_action('admin_post_nopriv_patient_registration_form_submit', 'handle_patient_registration_form_submission');
add_action('admin_post_patient_registration_form_submit', 'handle_patient_registration_form_submission');
