<?php
require_once AIVORY_INCLUDES_PATH . 'core.php';
require_once AIVORY_INCLUDES_PATH . 'helper.php';

function normalizePatientRegistrationRedirectUrl(string $url): string
{
    $url = trim($url);
    if (str_starts_with($url, '/') && !str_starts_with($url, '//')) {
        $url = home_url($url);
    }
    return esc_url_raw($url, ['http', 'https']);
}

function signPatientRegistrationRedirectUrl(string $url): string
{
    return wp_hash($url);
}

function getPatientRegistrationSuccessUrl(): ?string
{
    $url = esc_url_raw(wp_unslash($_POST['redirectUrl'] ?? ''), ['http', 'https']);
    $signature = sanitize_text_field($_POST['redirectSignature'] ?? '');
    if ($url === '' || !hash_equals(signPatientRegistrationRedirectUrl($url), $signature)) {
        return null;
    }
    return $url;
}

function handle_patient_registration_form_submission()
{
    if (!isset($_POST['patient_registration_form_nonce'])) {
        wp_safe_redirect(add_query_arg(['aivory_status' => 'api_error'], wp_get_referer()));
        exit;
    }
    $payload = [
        "firstName" => sanitize_text_field($_POST['firstName']),
        "lastName" => sanitize_text_field($_POST['lastName']),
        "initials" => sanitize_text_field($_POST['initials']),
        "dateOfBirth" => sanitize_text_field($_POST['dateOfBirth']),
        "gender" => sanitize_text_field($_POST['gender']),
        "email" => sanitize_email($_POST['email']),
        "phone" => sanitize_text_field($_POST['phone']),
        "street" => sanitize_text_field($_POST['street']),
        "postalCode" => sanitize_text_field($_POST['postalCode']),
        "city" => sanitize_text_field($_POST['city']),
        "bsn" => isset($_POST['bsn']) ? sanitize_text_field($_POST['bsn']) : null,
        "insuranceNumber" => isset($_POST['insuranceNumber']) ? sanitize_text_field($_POST['insuranceNumber']) : null,
        "locationId" => sanitize_text_field($_POST['location']),
        "acquisitionSource" => "WEBSITE",
        "captchaToken" => isset($_POST['cf-turnstile-response']) ? sanitize_text_field($_POST['cf-turnstile-response']) : null,
        "formAnswers" => buildFormAnswersFromPost($_POST),
    ];
    if (isset($_POST['formLoadToken'])) {
        $payload['formLoadToken'] = sanitize_text_field($_POST['formLoadToken']);
    }
    $response = submitPatientRegistration($payload);
    $successUrl = getPatientRegistrationSuccessUrl();
    if ($response['success'] && $successUrl) {
        wp_redirect($successUrl);
    } elseif ($response['success']) {
        wp_safe_redirect(add_query_arg(['aivory_status' => 'success','aivory_message' => $response['message']], wp_get_referer()));
    } else {
        wp_safe_redirect(add_query_arg(['aivory_status' => 'api_error','aivory_message' => $response['message']], wp_get_referer()));
    }
    exit;
}

add_action('admin_post_nopriv_patient_registration_form_submit', 'handle_patient_registration_form_submission');
add_action('admin_post_patient_registration_form_submit', 'handle_patient_registration_form_submission');
