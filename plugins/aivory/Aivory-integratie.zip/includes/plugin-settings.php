<?php

add_action('admin_menu', function () {
    add_options_page('Aivory Integratie Instellingen', 'Aivory', 'manage_options', 'aivory', 'aivory_settings_page');
});

add_action('admin_init', function () {
    register_setting('aivory_options', 'aivory_tenant_id');
    register_setting('aivory_options', 'aivory_cloudflare_site_key');
    register_setting('aivory_options', 'aivory_cloudflare_secret_key');
});

function aivory_settings_page()
{
    include_once AIVORY_VIEWS_PATH . 'settings.php';
}
