<?php
require_once AIVORY_INCLUDES_PATH . 'core.php';

add_action('admin_menu', function () {
    add_options_page('Aivory Integratie Instellingen', 'Aivory', 'manage_options', 'aivory', 'aivory_settings_page');
});

add_action('admin_post_aivory_clear_cache', 'handle_aivory_clear_cache');
function handle_aivory_clear_cache()
{
    if (!current_user_can('manage_options')) {
        wp_die('Onvoldoende rechten.', 403);
    }
    check_admin_referer('aivory_clear_cache_action', 'aivory_clear_cache_nonce');
    aivoryClearCache();
    wp_safe_redirect(add_query_arg('aivory_cache_cleared', '1', admin_url('options-general.php?page=aivory')));
    exit;
}

add_action('admin_init', function () {
    register_setting('aivory_options', 'aivory_tenant_id');
    register_setting('aivory_options', 'aivory_cloudflare_site_key');
    register_setting('aivory_options', 'aivory_cloudflare_secret_key');
});

function aivory_settings_page()
{
    include_once AIVORY_VIEWS_PATH . 'settings.php';
}
