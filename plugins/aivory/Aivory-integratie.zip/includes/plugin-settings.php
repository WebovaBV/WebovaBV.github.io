<?php
require_once AIVORY_INCLUDES_PATH . 'core.php';

add_action('admin_menu', function () {
    add_options_page('Aivory Integratie Instellingen', 'Aivory', 'manage_options', 'aivory', 'aivory_settings_page');
});

add_action('admin_post_aivory_clear_cache', 'handle_aivory_clear_cache');
function handle_aivory_clear_cache()
{
    if (!current_user_can('manage_options')) {
        wp_die('Onvoldoende rechten.', 403);
    }
    check_admin_referer('aivory_clear_cache_action', 'aivory_clear_cache_nonce');
    aivoryClearCache();
    wp_safe_redirect(add_query_arg('aivory_cache_cleared', '1', admin_url('options-general.php?page=aivory')));
    exit;
}

add_action('admin_post_aivory_test_branding', 'handle_aivory_test_branding');
function handle_aivory_test_branding()
{
    if (!current_user_can('manage_options')) {
        wp_die('Onvoldoende rechten.', 403);
    }
    check_admin_referer('aivory_test_branding_action');
    delete_transient('aivory_branding_' . getTenantId());
    set_transient('aivory_branding_test_result', testTenantBrandingConnection(), 60);
    wp_safe_redirect(admin_url('options-general.php?page=aivory'));
    exit;
}

add_action('admin_init', function () {
    register_setting('aivory_options', 'aivory_tenant_id');
    register_setting('aivory_options', 'aivory_cloudflare_site_key');
});

function aivory_settings_page()
{
    include_once AIVORY_VIEWS_PATH . 'settings.php';
}
