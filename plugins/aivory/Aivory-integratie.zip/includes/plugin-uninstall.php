<?php
register_uninstall_hook(__FILE__, 'aivory_uninstall');

function aivory_uninstall()
{
    delete_option('aivory_tenant_id');
}
