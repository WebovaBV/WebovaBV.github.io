<?php

function getRegistrationFormQuestions(array $form): array
{
    $questions = [];
    foreach ($form['sections'] ?? [] as $section) {
        foreach ($section['questions'] ?? [] as $question) {
            $questions[] = $question;
        }
    }
    if (empty($questions)) {
        $questions = $form['questions'] ?? [];
    }
    return $questions;
}

function buildFormAnswersFromPost(array $post): array
{
    $answers = [];

    foreach ($post['formAnswers'] ?? [] as $questionId => $value) {
        $questionId = sanitize_text_field($questionId);
        $values = is_array($value) ? $value : [$value];
        foreach ($values as $singleValue) {
            $singleValue = sanitize_text_field($singleValue);
            if ($singleValue === '') {
                continue;
            }
            $answers[] = [
                'questionId' => $questionId,
                'answerValue' => $singleValue,
                'isFollowUpAnswer' => false,
            ];
        }
    }

    foreach ($post['formAnswersFollowUp'] ?? [] as $questionId => $value) {
        $value = sanitize_text_field($value);
        if ($value === '') {
            continue;
        }
        $answers[] = [
            'questionId' => sanitize_text_field($questionId),
            'answerValue' => $value,
            'isFollowUpAnswer' => true,
        ];
    }

    return $answers;
}
