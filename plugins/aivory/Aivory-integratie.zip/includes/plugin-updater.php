<?php
// Lets WordPress update this plugin from the public update.json we publish,
// so a new version installs from the plugins screen without a manual download.

if (!defined('ABSPATH')) exit;

define('AIVORY_UPDATE_BASE', 'https://WebovaBV.github.io/plugins/aivory');
define('AIVORY_UPDATE_MANIFEST', AIVORY_UPDATE_BASE . '/update.json');

function aivoryPluginBasename()
{
    return plugin_basename(AIVORY_PLUGIN_FILE);
}

function aivoryPluginSlug()
{
    return dirname(aivoryPluginBasename());
}

function aivoryCurrentVersion()
{
    $data = get_file_data(AIVORY_PLUGIN_FILE, ['Version' => 'Version']);
    return $data['Version'];
}

function aivoryUpdateManifest()
{
    $cache_key = 'aivory_updater_manifest';
    $cached = get_transient($cache_key);
    if ($cached !== false) {
        return $cached ?: null;
    }

    $response = wp_remote_get(AIVORY_UPDATE_MANIFEST, ['timeout' => 15]);

    if (is_wp_error($response) || wp_remote_retrieve_response_code($response) !== 200) {
        set_transient($cache_key, [], HOUR_IN_SECONDS); // Back off on failure instead of hammering
        return null;
    }

    $manifest = json_decode(wp_remote_retrieve_body($response), true);
    if (empty($manifest['version']) || empty($manifest['download_url'])) {
        set_transient($cache_key, [], HOUR_IN_SECONDS);
        return null;
    }

    set_transient($cache_key, $manifest, 12 * HOUR_IN_SECONDS);
    return $manifest;
}

// Force a fresh lookup when the admin clicks "Check again".
add_action('load-update-core.php', function () {
    if (!empty($_GET['force-check'])) {
        delete_transient('aivory_updater_manifest');
    }
});

add_filter('pre_set_site_transient_update_plugins', 'aivoryCheckForUpdate');
function aivoryCheckForUpdate($transient)
{
    if (empty($transient->checked)) {
        return $transient;
    }

    $manifest = aivoryUpdateManifest();
    if (!$manifest) {
        return $transient;
    }

    $basename = aivoryPluginBasename();
    $current = $transient->checked[$basename] ?? aivoryCurrentVersion();
    $latest = ltrim($manifest['version'], 'vV');

    if (version_compare($latest, $current, '>')) {
        $transient->response[$basename] = (object) [
            'slug' => aivoryPluginSlug(),
            'plugin' => $basename,
            'new_version' => $latest,
            'package' => $manifest['download_url'],
            'url' => $manifest['homepage'] ?? AIVORY_UPDATE_BASE,
            'tested' => $manifest['tested'] ?? '',
            'requires' => $manifest['requires'] ?? '',
            'requires_php' => $manifest['requires_php'] ?? '',
            'icons' => $manifest['icons'] ?? [],
            'banners' => $manifest['banners'] ?? [],
        ];
    } else {
        unset($transient->response[$basename]);
        $transient->no_update[$basename] = (object) [
            'slug' => aivoryPluginSlug(),
            'plugin' => $basename,
            'new_version' => $current,
            'package' => '',
            'url' => $manifest['homepage'] ?? AIVORY_UPDATE_BASE,
        ];
    }

    return $transient;
}

add_filter('plugins_api', 'aivoryPluginInfo', 20, 3);
function aivoryPluginInfo($result, $action, $args)
{
    if ($action !== 'plugin_information' || ($args->slug ?? '') !== aivoryPluginSlug()) {
        return $result;
    }

    $manifest = aivoryUpdateManifest();
    if (!$manifest) {
        return $result;
    }

    if (!function_exists('get_plugin_data')) {
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
    }
    $data = get_plugin_data(AIVORY_PLUGIN_FILE, false, false);

    return (object) [
        'name' => $data['Name'],
        'slug' => aivoryPluginSlug(),
        'version' => ltrim($manifest['version'], 'vV'),
        'author' => $data['Author'],
        'homepage' => $manifest['homepage'] ?? $data['PluginURI'],
        'download_link' => $manifest['download_url'],
        'requires' => $manifest['requires'] ?? ($data['RequiresWP'] ?? ''),
        'requires_php' => $manifest['requires_php'] ?? ($data['RequiresPHP'] ?? ''),
        'tested' => $manifest['tested'] ?? '',
        'last_updated' => $manifest['last_updated'] ?? '',
        'icons' => $manifest['icons'] ?? [],
        'banners' => $manifest['banners'] ?? [],
        'sections' => [
            'description' => $data['Description'],
            'changelog' => aivoryFormatChangelog($manifest),
        ],
    ];
}

function aivoryFormatChangelog($manifest)
{
    $changelog = trim($manifest['changelog'] ?? '');
    if ($changelog === '') {
        return 'Geen changelog beschikbaar.';
    }
    return wp_kses_post(wpautop($changelog));
}

// The zip holds the plugin files at its root; move them into a folder named
// after the installed plugin so WordPress overwrites the plugin in place.
add_filter('upgrader_source_selection', 'aivoryRenameUpdateFolder', 10, 4);
function aivoryRenameUpdateFolder($source, $remote_source, $upgrader, $hook_extra = [])
{
    if (($hook_extra['plugin'] ?? '') !== aivoryPluginBasename()) {
        return $source;
    }

    global $wp_filesystem;
    $slug = aivoryPluginSlug();
    $desired = trailingslashit($remote_source) . $slug;

    if (untrailingslashit($source) === $desired) {
        return trailingslashit($desired);
    }

    // Files extracted straight into the working dir: move them into a subfolder.
    if (untrailingslashit($source) === untrailingslashit($remote_source)) {
        $wp_filesystem->mkdir($desired);
        foreach (array_keys($wp_filesystem->dirlist($source)) as $name) {
            if ($name === $slug) {
                continue;
            }
            $wp_filesystem->move(trailingslashit($source) . $name, trailingslashit($desired) . $name, true);
        }
        return trailingslashit($desired);
    }

    // Extracted into a wrapper folder: rename it to the plugin slug.
    if ($wp_filesystem->move(untrailingslashit($source), $desired, true)) {
        return trailingslashit($desired);
    }

    return $source;
}
