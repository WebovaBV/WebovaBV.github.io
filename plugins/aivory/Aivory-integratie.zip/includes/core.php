<?php

function getTenantId()
{
    return esc_attr(get_option('aivory_tenant_id', null));
}

function getTenantLocations()
{
    $tenantId = getTenantId();
    $cache_key = 'aivory_locations_' . $tenantId;
    $cached_locations = get_transient($cache_key);

    if ($cached_locations !== false) {
        return json_decode($cached_locations, true);
    } else {
        $response = wp_remote_get(AIVORY_API_URL . "public/practice/$tenantId/locations");
        if (is_wp_error($response)) {
            return [];
        }
        $body = wp_remote_retrieve_body($response);

        $data = json_decode($body, true);
        $statusCode = $data['statusCode'] ?? 200;
        if ($statusCode !== 200) {
            return [];
        } else {
            // Cache the locations for future requests only if the API call was successful
            set_transient($cache_key, $body, 1800); // Cache for 30 minutes
        }
        return $data;
    }
}

function submitPatientRegistration(array $payload)
{
    $tenantId = getTenantId();
    $response = wp_remote_post(AIVORY_API_URL . "public/registration/$tenantId", [
        'timeout' => 15,
        'headers' => [
            'Content-Type' => 'application/json',
        ],
        'body' => wp_json_encode($payload)
    ]);
    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);
    $callBack = [
        "success" => $data['success'] ?? false,
        "message" => $data['message'] ?? ''
    ];
    return $callBack;
}
