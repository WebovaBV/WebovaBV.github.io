<?php

function aivoryClearCache()
{
    $tenantId = getTenantId();
    delete_transient('aivory_locations_' . $tenantId);
    delete_transient('aivory_appointment_types_' . $tenantId);

    // Sweep any leftover transients (e.g. from a previously configured tenant).
    global $wpdb;
    $wpdb->query(
        "DELETE FROM {$wpdb->options}
         WHERE option_name LIKE '\_transient\_aivory\_%'
            OR option_name LIKE '\_transient\_timeout\_aivory\_%'"
    );
}

function getTenantId()
{
    return esc_attr(get_option('aivory_tenant_id', null));
}

function getTenantLocations()
{
    $tenantId = getTenantId();
    $cache_key = 'aivory_locations_' . $tenantId;
    $cached_locations = get_transient($cache_key);

    if ($cached_locations !== false) {
        return json_decode($cached_locations, true);
    } else {
        $response = wp_remote_get(AIVORY_API_URL . "public/practice/$tenantId/locations");
        if (is_wp_error($response)) {
            return [];
        }
        $body = wp_remote_retrieve_body($response);

        $data = json_decode($body, true);
        $statusCode = $data['statusCode'] ?? 200;
        if ($statusCode !== 200) {
            return [];
        } else {
            // Cache the locations for future requests only if the API call was successful
            set_transient($cache_key, $body, 1800); // Cache for 30 minutes
        }
        return $data;
    }
}

function getTenantBranding()
{
    $tenantId = getTenantId();
    $cache_key = 'aivory_branding_' . $tenantId;
    $cached_branding = get_transient($cache_key);
    if ($cached_branding !== false) {
        return json_decode($cached_branding, true);
    } else {
        $response = wp_remote_get(AIVORY_API_URL . "public/practice/$tenantId/branding");
        if (is_wp_error($response)) {
            return [];
        }
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        $statusCode = $data['statusCode'] ?? 200;
        if ($statusCode !== 200) {
            return [];
        } else {
            // Cache the branding for future requests only if the API call was successful
            set_transient($cache_key, $body, 1800); // Cache for 30 minutes
        }
        return $data;
    }
}

function getAppointmentTypes()
{
    $tenantId = getTenantId();
    $cache_key = 'aivory_appointment_types_' . $tenantId;
    $cached = get_transient($cache_key);

    if ($cached !== false) {
        $decoded = json_decode($cached, true);
        if (!empty($decoded)) {
            return $decoded;
        }
    }

    $response = wp_remote_get(AIVORY_API_URL . "public/booking/$tenantId/appointment-types");
    if (is_wp_error($response)) {
        return [];
    }
    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);
    if (!is_array($data) || isset($data['statusCode']) || empty($data)) {
        return [];
    }
    set_transient($cache_key, $body, 1800); // Cache for 30 minutes, only non-empty results
    return $data;
}

function getFormSchema(string $formId)
{
    $tenantId = getTenantId();
    $cache_key = 'aivory_form_schema_' . $formId;
    $cached = get_transient($cache_key);

    if ($cached !== false) {
        $decoded = json_decode($cached, true);
        if (!empty($decoded)) {
            return $decoded;
        }
    }

    $response = wp_remote_get(AIVORY_API_URL . "public/forms/$tenantId/$formId/schema");
    if (is_wp_error($response)) {
        return [];
    }
    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);
    $statusCode = $data['statusCode'] ?? 200;
    if ($statusCode !== 200 || empty($data)) {
        return [];
    } else {
        set_transient($cache_key, $body, 1800); // Cache for 30 minutes, only non-empty results
    }
    return $data;
}

function getTenantRegistrationForm()
{
    $tenantId = getTenantId();
    $branding = getTenantBranding();
    $formId = $branding['registrationFormId'] ?? null;
    $formSchema = $formId ? getFormSchema($formId) : [];
    return $formSchema;
}

function submitPatientRegistration(array $payload)
{
    $tenantId = getTenantId();
    $response = wp_remote_post(AIVORY_API_URL . "public/registration/$tenantId", [
        'timeout' => 15,
        'headers' => [
            'Content-Type' => 'application/json',
        ],
        'body' => wp_json_encode($payload)
    ]);
    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);
    $callBack = [
        "success" => $data['success'] ?? false,
        "message" => $data['message'] ?? ''
    ];
    return $callBack;
}

function aivoryBookingRequestLink(string $email, string $dateOfBirth)
{
    $tenantId = getTenantId();
    $response = wp_remote_post(AIVORY_API_URL . "public/booking/$tenantId/request-link", [
        'timeout' => 15,
        'headers' => ['Content-Type' => 'application/json'],
        'body' => wp_json_encode([
            'email' => $email,
            'dateOfBirth' => $dateOfBirth,
        ])
    ]);
    if (is_wp_error($response)) {
        return ['success' => false, 'message' => 'Er is een fout opgetreden. Probeer het later opnieuw.'];
    }
    $data = json_decode(wp_remote_retrieve_body($response), true);
    return [
        'success' => $data['success'] ?? false,
        'message' => $data['message'] ?? ''
    ];
}

function aivoryBookingVerifyCode(string $email, string $code)
{
    $tenantId = getTenantId();
    $response = wp_remote_post(AIVORY_API_URL . "public/booking/$tenantId/verify-code", [
        'timeout' => 15,
        'headers' => ['Content-Type' => 'application/json'],
        'body' => wp_json_encode([
            'email' => $email,
            'code' => $code,
        ])
    ]);
    if (is_wp_error($response)) {
        return ['success' => false, 'message' => 'Er is een fout opgetreden. Probeer het later opnieuw.'];
    }
    $data = json_decode(wp_remote_retrieve_body($response), true);
    return [
        'success' => $data['success'] ?? false,
        'bookingToken' => $data['bookingToken'] ?? null,
        'message' => $data['message'] ?? ''
    ];
}

function aivoryBookingAvailableDays(string $token, string $appointmentTypeId, string $month)
{
    $tenantId = getTenantId();
    $url = add_query_arg([
        'appointmentTypeId' => $appointmentTypeId,
        'month' => $month,
    ], AIVORY_API_URL . "public/booking/$tenantId/available-days");
    $response = wp_remote_get($url, [
        'timeout' => 15,
        'headers' => ['x-booking-token' => $token],
    ]);
    if (is_wp_error($response)) {
        return [];
    }
    $data = json_decode(wp_remote_retrieve_body($response), true);
    return is_array($data) && !isset($data['statusCode']) ? $data : [];
}

function aivoryBookingAvailableTimes(string $token, string $appointmentTypeId, string $date)
{
    $tenantId = getTenantId();
    $url = add_query_arg([
        'appointmentTypeId' => $appointmentTypeId,
        'date' => $date,
    ], AIVORY_API_URL . "public/booking/$tenantId/available-times");
    $response = wp_remote_get($url, [
        'timeout' => 15,
        'headers' => ['x-booking-token' => $token],
    ]);
    if (is_wp_error($response)) {
        return [];
    }
    $data = json_decode(wp_remote_retrieve_body($response), true);
    if (!is_array($data) || isset($data['statusCode'])) {
        return [];
    }
    return array_map('aivoryAddLocalTime', $data);
}

function aivoryAddLocalTime(array $slot): array
{
    if (empty($slot['startTime'])) {
        return $slot;
    }
    try {
        $dt = new DateTime($slot['startTime']);
        $dt->setTimezone(wp_timezone());
        $slot['displayTime'] = $dt->format('H:i');
    } catch (Exception $e) {
        $slot['displayTime'] = substr($slot['startTime'], 11, 5);
    }
    return $slot;
}

function aivoryBookingConfirm(string $token, array $payload)
{
    $tenantId = getTenantId();
    $response = wp_remote_post(AIVORY_API_URL . "public/booking/$tenantId/book", [
        'timeout' => 15,
        'headers' => [
            'Content-Type' => 'application/json',
            'x-booking-token' => $token,
        ],
        'body' => wp_json_encode($payload)
    ]);
    if (is_wp_error($response)) {
        return ['success' => false, 'message' => 'Er is een fout opgetreden. Probeer het later opnieuw.'];
    }
    $data = json_decode(wp_remote_retrieve_body($response), true);
    return [
        'success' => $data['success'] ?? false,
        'message' => $data['message'] ?? '',
        'appointmentDate' => $data['appointmentDate'] ?? '',
        'appointmentTime' => $data['appointmentTime'] ?? '',
        'practitionerName' => $data['practitionerName'] ?? ''
    ];
}
