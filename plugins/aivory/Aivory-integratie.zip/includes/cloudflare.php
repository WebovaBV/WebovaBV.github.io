<?php

function getCloudflareTurnstileSiteKey()
{
    return esc_attr(get_option('aivory_cloudflare_site_key', null));
}
