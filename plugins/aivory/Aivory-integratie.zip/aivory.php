<?php
/*
Plugin Name: Aivory integratie
Description: Maakt een exclusieve API-koppeling tussen Aivory B.V. en Webova Nederland B.V. voor patiëntregistratie en online afspraakplanning.
Version: 1.2.1
Author: Webova Nederland B.V.
Requires Plugins: elementor
Plugin URI: https://github.com/WebovaBV/Aivory-wordpress
Author URI: https://Webova.nl
*/

// Prevent direct access
if ( !defined( 'ABSPATH' ) ) exit;

define('AIVORY_API_URL', 'https://api.aivory.nl/');
define('AIVORY_VIEWS_PATH', plugin_dir_path(__FILE__) . 'views/');
define('AIVORY_INCLUDES_PATH', plugin_dir_path(__FILE__) . 'includes/');

include_once AIVORY_INCLUDES_PATH . 'plugin-settings.php';
include_once AIVORY_INCLUDES_PATH . 'plugin-uninstall.php';
include_once AIVORY_INCLUDES_PATH . 'widget/patient-registration.php';
